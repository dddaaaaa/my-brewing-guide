package dev.thorinwasher.blockanimator.minestom;

import net.minestom.server.entity.Entity;
import net.minestom.server.entity.EntityType;
import net.minestom.server.entity.metadata.display.BlockDisplayMeta;
import net.minestom.server.instance.Instance;
import net.minestom.server.instance.block.Block;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3d;
import org.joml.Vector3f;

public class BlockAnimationUtils {


    public static Entity spawnBlockDisplay(Vector3d position, Block block, Instance instance, Matrix4f transform) {
        Entity blockDisplay = new Entity(EntityType.BLOCK_DISPLAY);
        BlockDisplayMeta blockDisplayMeta = (BlockDisplayMeta) blockDisplay.getEntityMeta();
        blockDisplayMeta.setBlockState(block);
        blockDisplayMeta.setHasNoGravity(true);
        applyTransform(blockDisplay, transform);
        blockDisplay.setInstance(instance, VectorConversion.toVec(position));
        return blockDisplay;
    }

    /**
     * @param transform null means identity
     */
    public static void applyTransform(Entity entity, Matrix4f transform) {
        if (transform == null) {
            transform = new Matrix4f();
        }
        BlockDisplayMeta blockDisplayMeta = (BlockDisplayMeta) entity.getEntityMeta();
        Quaternionf rotation = transform.getUnnormalizedRotation(new Quaternionf());
        blockDisplayMeta.setLeftRotation(new float[]{rotation.x, rotation.y, rotation.z, rotation.w});
        Vector3f scale = transform.getScale(new Vector3f());
        blockDisplayMeta.setScale(VectorConversion.toVec(new Vector3d(scale)));
        Vector3f translation = transform.getTranslation(new Vector3f());
        blockDisplayMeta.setTranslation(VectorConversion.toVec(new Vector3d(translation)));
    }
}
