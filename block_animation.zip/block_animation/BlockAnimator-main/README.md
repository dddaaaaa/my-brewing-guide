<p align="center">
    <a href="https://search.maven.org/search?q=dev.thorinwasher.blockanimator">
        <img alt="Maven Central" src="https://img.shields.io/maven-central/v/dev.thorinwasher.blockanimator/blockanimator-paper?color=1bcc94&logo=apache-maven" />
    </a>
</p>


# Project status
This project is still in early development, expect issues and don't use in production.

Paper support targets **1.21.11 and newer** (Java 21). Older server versions are not supported.

# How to import
Firstly you need to add the repository used by this project:
```kts
repositories {
  mavenCentral()
}
```
## Minestom
```kts
implementation("dev.thorinwasher.blockanimator:blockanimator-api:<version>")
implementation("dev.thorinwasher.blockanimator:blockanimator-minestom:<version>")
implementation("org.joml:joml:1.10.8")
```
## Paper
```kts
implementation("dev.thorinwasher.blockanimator:blockanimator-api:<version>")
implementation("dev.thorinwasher.blockanimator:blockanimator-paper:<version>")
```
Shade (and relocate) the two packages above into your plugin. **Do not shade or relocate JOML**: Paper already ships it,
and the display entity API expects `org.joml` classes.

# Some examples on uses
## Paper
```java
PathCompletionSupplier pathCompletionSupplier = new EaseOutCubicPathCompletionSupplier(0.2);
BlockMoveAnimation blockMoveAnimation = new BlockMoveLinear(VectorConverter.toVector3d(startLocation), pathCompletionSupplier);
BlockTimer blockTimer = new LinearBlockTimer(200);
BlockSelector blockSelector = new GrowingDendriteSelector(0.2);
Animation<BlockData> animation = new TimerAnimation<>(blockSelector, blockMoveAnimation, blockSupplier, blockTimer, 100);
// Compile async, otherwise the main thread freezes. Never touch the world from BlockSupplier#getPositions.
Bukkit.getScheduler().runTaskAsynchronously(plugin, animation::compile);
// updateInterval = 2: every block sends its position every second tick, the client interpolates in between
Animator<BlockData> animator = new Animator<>(animation, new PlaceBlocksAfterBlockAnimator(world, 500, 2));
Bukkit.getScheduler().runTaskTimer(plugin, task -> {
    if (animator.nextTick()) {
        task.cancel();
    }
}, 0, 1);
// On plugin disable: animator.emergencyFinish() places the rest of the structure and removes all entities
```
Selectors and timers can be reused for several animations, but one `Animation` instance is compiled once.

## Minestom
```java
PathCompletionSupplier pathCompletionSupplier = new EaseOutCubicPathCompletionSupplier(0.2);
BlockMoveAnimation blockMoveAnimation = new BlockMoveLinear(VectorConversion.toVector3d(startingPointLocation), pathCompletionSupplier);
BlockTimer blockTimer = new LinearBlockTimer(blockQueryTime);
BlockSupplier<Block> blockSupplier = new SchemBlockSupplier(hollowcubeSchemInstance, rotation, cornerPoint, instance);
BlockSelector blockSelector = new GrowingDendriteSelector(0.2);
Animation<Block> animation = new TimerAnimation<>(blockSelector, blockMoveAnimation, blockSupplier, blockTimer, 100);
Thread thread = new Thread(animation::compile);
thread.start();
Animator<Block> animator = new Animator<>(animation, new PlaceBlocksAfterBlockAnimator(1000, instance));
Task timer = MinecraftServer.getSchedulerManager().scheduleTask(animator::nextTick, TaskSchedule.immediate(), TaskSchedule.tick(1));
animator.addOnCompletion(timer::cancel);
```
