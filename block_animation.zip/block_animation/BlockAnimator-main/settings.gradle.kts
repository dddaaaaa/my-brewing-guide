pluginManagement {
    repositories {
        gradlePluginPortal()
    }
}

rootProject.name = "blockanimator"

include("api")
include("minestom")
include("paper")
include("minestomtest")
include("worldedit")
include("papertest:shared")
include("papertest:v1_21")
include("snowman")
