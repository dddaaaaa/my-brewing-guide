plugins {
    id("java")
    id("xyz.jpenilla.run-paper") version "2.3.1"
    id("com.gradleup.shadow") version "8.3.9"
}

group = "dev.thorinwasher.blockanimator"
version = System.getenv("VERSION") ?: "development"

repositories {
    mavenCentral()
    maven {
        url = uri("https://repo.papermc.io/repository/maven-public/")
    }
    maven("https://maven.enginehub.org/repo/")
}

java.toolchain {
    languageVersion = JavaLanguageVersion.of(21)
}

dependencies {
    implementation(project(":papertest:shared"))
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
}

tasks {
    runServer {
        minecraftVersion("1.21.11")
        downloadPlugins {
            modrinth("worldedit", "7.3.19")
        }
    }

    // JOML не кладём в jar: Paper 1.21 уже содержит его, а Display API принимает именно org.joml
    shadowJar {
        dependencies {
            include(project(":api"))
            include(project(":paper"))
            include(project(":worldedit"))
            include(project(":papertest:shared"))
        }
    }
}
