plugins {
    id("java")
}

group = "dev.thorinwasher.blockanimator"
version = System.getenv("VERSION") ?: "development"

repositories {
    mavenCentral()
    maven {
        url = uri("https://repo.papermc.io/repository/maven-public/")
    }
    maven("https://maven.enginehub.org/repo/")
}

java.toolchain {
    languageVersion = JavaLanguageVersion.of(21)
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
    compileOnly("com.sk89q.worldedit:worldedit-core:7.3.19")
    compileOnly("com.sk89q.worldedit:worldedit-bukkit:7.3.19")
    implementation(project(":api"))
    implementation(project(":paper"))
    implementation(project(":worldedit"))
}

tasks {
    processResources {
        filesMatching("**/plugin.yml") { expand(project.properties) }
    }
}
