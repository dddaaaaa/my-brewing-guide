package dev.thorinwasher.blockanimator.worldedit;

import com.sk89q.worldedit.math.BlockVector3;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;

public class WEVectorConverter {

    public static BlockVector3 toBlockVector3(ImmutableVector3i vector) {
        return BlockVector3.at(vector.x(), vector.y(), vector.z());
    }

    public static ImmutableVector3i toImmutableVector3i(BlockVector3 blockVector3) {
        return new ImmutableVector3i(blockVector3.x(), blockVector3.y(), blockVector3.z());
    }
}
