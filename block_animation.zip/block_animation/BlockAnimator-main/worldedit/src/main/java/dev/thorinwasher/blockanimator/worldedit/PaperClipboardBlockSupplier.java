package dev.thorinwasher.blockanimator.worldedit;

import com.sk89q.worldedit.WorldEditException;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.transform.BlockTransformExtent;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.math.transform.Transform;
import com.sk89q.worldedit.util.SideEffect;
import com.sk89q.worldedit.util.SideEffectSet;
import com.sk89q.worldedit.world.block.BaseBlock;
import dev.thorinwasher.blockanimator.api.supplier.BlockSupplier;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import org.bukkit.Location;
import org.bukkit.block.data.BlockData;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PaperClipboardBlockSupplier implements BlockSupplier<BlockData> {

    private static final Logger LOGGER = Logger.getLogger(PaperClipboardBlockSupplier.class.getName());
    private final Clipboard clipboard;
    private final ImmutableVector3i origin;
    private final com.sk89q.worldedit.world.World world;
    private final Transform transform;
    private final Transform transformInverse;
    private final boolean includeAir;
    private static final SideEffectSet SIDE_EFFECT_SET = SideEffectSet.none()
            .with(SideEffect.NETWORK, SideEffect.State.ON)
            .with(SideEffect.LIGHTING, SideEffect.State.ON);

    public PaperClipboardBlockSupplier(Clipboard clipboard, Location origin, Transform transform) throws WorldEditException {
        this(clipboard, origin, transform, false);
    }

    /**
     * @param includeAir whether air blocks of the clipboard are animated too. With true the air overwrites whatever
     *                   is in the world, like {@code //paste} without {@code -a}
     */
    public PaperClipboardBlockSupplier(Clipboard clipboard, Location origin, Transform transform, boolean includeAir) throws WorldEditException {
        this.clipboard = clipboard;
        this.origin = new ImmutableVector3i(origin.getBlockX(), origin.getBlockY(), origin.getBlockZ());
        this.world = BukkitAdapter.adapt(origin.getWorld());
        this.transform = transform;
        this.transformInverse = transform.inverse();
        this.includeAir = includeAir;
    }

    @Override
    public BlockData getBlock(ImmutableVector3i targetPosition) {
        return BukkitAdapter.adapt(getBlock(toRegionPosition(targetPosition)));
    }

    @Override
    public List<ImmutableVector3i> getPositions() {
        List<ImmutableVector3i> output = new ArrayList<>();
        for (BlockVector3 blockVector3 : clipboard.getRegion()) {
            // Воздух раньше тоже «летел»: тратил сущности и затирал блоки мира в области вставки
            if (!includeAir && clipboard.getBlock(blockVector3).getBlockType().getMaterial().isAir()) {
                continue;
            }
            BlockVector3 relativePosition = applyTransform(blockVector3.subtract(clipboard.getOrigin()));
            output.add(WEVectorConverter.toImmutableVector3i(relativePosition).add(origin));
        }
        return output;
    }

    @Override
    public void placeBlock(ImmutableVector3i identifier) {
        placeBlocks(List.of(identifier));
    }

    @Override
    public void placeBlocks(List<ImmutableVector3i> identifiers) {
        for (ImmutableVector3i identifier : identifiers) {
            try {
                world.setBlock(WEVectorConverter.toBlockVector3(identifier), getBlock(toRegionPosition(identifier)), SIDE_EFFECT_SET);
            } catch (WorldEditException e) {
                // Один сбойный блок не должен оставлять дыру из всех следующих в пачке
                LOGGER.log(Level.WARNING, "Could not place block at " + identifier, e);
            }
        }
    }

    private BlockVector3 toRegionPosition(ImmutableVector3i worldPosition) {
        return applyTransformInverse(WEVectorConverter.toBlockVector3(worldPosition.sub(origin))).add(clipboard.getOrigin());
    }

    private BaseBlock getBlock(BlockVector3 regionPosition) {
        BaseBlock baseBlock = clipboard.getFullBlock(regionPosition);
        return BlockTransformExtent.transform(baseBlock, transform);
    }

    private BlockVector3 applyTransform(BlockVector3 blockVector3) {
        return transform.apply(blockVector3.toVector3()).toBlockPoint();
    }

    private BlockVector3 applyTransformInverse(BlockVector3 blockVector3) {
        return transformInverse.apply(blockVector3.toVector3()).toBlockPoint();
    }
}
