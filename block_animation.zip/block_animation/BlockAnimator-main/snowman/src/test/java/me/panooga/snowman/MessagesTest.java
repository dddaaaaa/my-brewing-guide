package me.panooga.snowman;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Каждый ключ из кода есть в messages.yml, и в файле нет забытых ключей.
 */
class MessagesTest {

    private static final Pattern CALL = Pattern.compile("Messages\\.(?:send|get|item|lore|broadcast|raw)\\(\\s*(?:[a-zA-Z]+\\s*,\\s*)?\"([a-z0-9-]*[a-z0-9])\"");
    private static final Pattern SITE_ERROR = Pattern.compile("new SiteException\\(\"([a-z0-9-]*[a-z0-9])\"");
    private static final Pattern MESSAGE_KEY = Pattern.compile("\\? \"([a-z0-9-]*[a-z0-9])\" : \"([a-z0-9-]*[a-z0-9])\"");
    // Ключи, которые собираются в коде из частей
    private static final Set<String> DYNAMIC = Set.of("state-idle", "state-collecting", "state-waiting", "state-building", "state-finished", "prefix");

    @Test
    void messageKeysMatchCode() throws IOException {
        Set<String> used = new TreeSet<>(DYNAMIC);
        try (Stream<Path> files = Files.walk(Path.of("src/main/java"))) {
            for (Path file : files.filter(path -> path.toString().endsWith(".java")).toList()) {
                String source = Files.readString(file);
                collect(CALL, source, used);
                collect(SITE_ERROR, source, used);
                Matcher ternary = MESSAGE_KEY.matcher(source);
                while (ternary.find()) {
                    used.add(ternary.group(1));
                    used.add(ternary.group(2));
                }
            }
        }
        YamlConfiguration messages = YamlConfiguration.loadConfiguration(new File("src/main/resources/messages.yml"));
        Set<String> defined = new TreeSet<>(messages.getKeys(false));
        Set<String> missing = new TreeSet<>(used);
        missing.removeAll(defined);
        Set<String> unused = new TreeSet<>(defined);
        unused.removeAll(used);
        assertEquals(Set.of(), missing, "keys used in code but missing in messages.yml");
        assertEquals(Set.of(), unused, "keys in messages.yml never used in code");
    }

    private static void collect(Pattern pattern, String source, Set<String> into) {
        Matcher matcher = pattern.matcher(source);
        while (matcher.find()) {
            into.add(matcher.group(1));
        }
    }

    @Test
    void configHasThreeLevels() {
        YamlConfiguration config = YamlConfiguration.loadConfiguration(new File("src/main/resources/config.yml"));
        assertEquals(3, config.getMapList("levels").size());
        assertEquals(new HashSet<>(Set.of(40, 68, 100)), new HashSet<>(config.getMapList("levels").stream()
                .map(level -> ((Number) level.get("height-percent")).intValue()).toList()));
    }
}
