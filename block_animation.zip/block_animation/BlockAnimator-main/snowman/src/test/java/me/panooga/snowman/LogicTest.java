package me.panooga.snowman;

import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import me.panooga.snowman.logic.Contributions;
import me.panooga.snowman.logic.DriftShape;
import me.panooga.snowman.logic.LevelPlan;
import me.panooga.snowman.logic.LevelProgress;
import me.panooga.snowman.site.BuiltinSnowman;
import org.bukkit.Material;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class LogicTest {

    @Test
    void levelsSplitByHeightCoverEverythingOnce() {
        List<ImmutableVector3i> blocks = new ArrayList<>();
        for (int y = 10; y < 30; y++) {
            blocks.add(new ImmutableVector3i(0, y, 0));
            blocks.add(new ImmutableVector3i(1, y, 0));
        }
        List<List<ImmutableVector3i>> levels = LevelPlan.split(blocks, List.of(40, 68, 90));
        assertEquals(3, levels.size());
        assertEquals(blocks.size(), levels.stream().mapToInt(List::size).sum());
        // 20 слоёв: 40% = 8 слоёв, 68% ≈ 14, последний добирает до верха даже при 90
        assertEquals(16, levels.get(0).size());
        assertEquals(12, levels.get(1).size());
        assertEquals(12, levels.get(2).size());
        int maxFirst = levels.get(0).stream().mapToInt(ImmutableVector3i::y).max().orElseThrow();
        int minSecond = levels.get(1).stream().mapToInt(ImmutableVector3i::y).min().orElseThrow();
        assertTrue(maxFirst < minSecond, "levels go bottom to top");
    }

    @Test
    void builtinSnowmanSplitsIntoThreeBalls() {
        for (int rotation : new int[]{0, 90, 180, 270}) {
            Map<ImmutableVector3i, Material> snowman = BuiltinSnowman.generate(rotation);
            assertTrue(snowman.size() > 400, "snowman blocks: " + snowman.size());
            List<List<ImmutableVector3i>> levels = LevelPlan.split(snowman.keySet(), List.of(40, 68, 100));
            levels.forEach(level -> assertFalse(level.isEmpty()));
            int height = snowman.keySet().stream().mapToInt(ImmutableVector3i::y).max().orElseThrow() + 1;
            assertEquals(22, height);
            // Голова со шляпой — в последнем уровне
            assertTrue(levels.get(2).stream().anyMatch(p -> snowman.get(p) == Material.BLACK_CONCRETE));
            assertTrue(levels.get(0).stream().noneMatch(p -> snowman.get(p) == Material.RED_WOOL));
            if (rotation == 0) {
                // Нос смотрит на север (-Z)
                assertTrue(snowman.entrySet().stream().anyMatch(e -> e.getValue() == Material.ORANGE_TERRACOTTA && e.getKey().z() < -2));
            }
        }
    }

    @Test
    void driftGrowsWithSupport() {
        List<ImmutableVector3i> drift = DriftShape.mound(4, 3, 7);
        assertTrue(drift.size() > 60, "drift size: " + drift.size());
        assertEquals(drift.size(), new HashSet<>(drift).size());
        Set<ImmutableVector3i> placed = new HashSet<>();
        for (ImmutableVector3i block : drift) {
            if (block.y() > 0) {
                assertTrue(placed.contains(block.add(0, -1, 0)), "block " + block + " grows on top of an existing one");
            }
            placed.add(block);
        }
        assertEquals(new ImmutableVector3i(0, 0, 0), drift.get(0), "grows from the center");
        assertEquals(drift, DriftShape.mound(4, 3, 7), "same seed, same drift after restart");
    }

    @Test
    void progressAcceptsOnlyWhatIsNeeded() {
        LevelProgress<String> progress = new LevelProgress<>(Map.of("snow", 100, "coal", 10));
        assertEquals(100, progress.add("snow", 150));
        assertEquals(0, progress.add("snow", 5));
        assertEquals(0, progress.add("dirt", 5));
        assertFalse(progress.isComplete());
        assertEquals(100.0 / 110, progress.fraction(), 1e-9);
        progress.add("coal", 10);
        assertTrue(progress.isComplete());
        assertEquals(1.0, progress.fraction(), 1e-9);

        LevelProgress<String> restored = new LevelProgress<>(Map.of("snow", 50));
        restored.restore("snow", 80);
        restored.restore("dirt", 3);
        assertEquals(50, restored.donated("snow"));
        assertEquals(0, restored.donated("dirt"));
        assertTrue(new LevelProgress<String>(Map.of()).isComplete());
    }

    @Test
    void leadersShareTheTopReward() {
        Contributions contributions = new Contributions();
        UUID a = UUID.randomUUID();
        UUID b = UUID.randomUUID();
        UUID c = UUID.randomUUID();
        contributions.add(a, "Alice", 10, 50);
        contributions.add(b, "Bob", 30, 30);
        contributions.add(b, "Bob", 5, 20);
        contributions.add(c, "Carl", 1, 1);
        contributions.add(UUID.randomUUID(), "Nobody", 0, 0);
        assertEquals(3, contributions.ranking().size(), "players without points are not ranked");
        // Равные очки: в таблице выше тот, кто сдал больше предметов, но награду получают оба
        assertEquals(b, contributions.ranking().get(0).id());
        assertEquals(Set.of(a, b), new HashSet<>(contributions.leaders().stream().map(Contributions.Entry::id).toList()));
        assertEquals(3, contributions.place(c));
        assertEquals(0, contributions.place(UUID.randomUUID()));
    }

    @Test
    void fractionalPointsAreExactAndReadable() {
        assertEquals(10, me.panooga.snowman.logic.Points.fromConfig(0.1));
        assertEquals(120, me.panooga.snowman.logic.Points.fromConfig(1.2));
        // 43 200 снежков по 0,1 — ровно 4 320, без хвоста от double
        assertEquals("4 320", me.panooga.snowman.logic.Points.format(43200 * me.panooga.snowman.logic.Points.fromConfig(0.1)));
        assertEquals("12,5", me.panooga.snowman.logic.Points.format(1250));
        assertEquals("0,64", me.panooga.snowman.logic.Points.format(64));
        assertEquals("130 820", me.panooga.snowman.logic.Points.format(13_082_000));
    }

    @Test
    void bundledConfigPhaseTotals() {
        org.bukkit.configuration.file.YamlConfiguration config = org.bukkit.configuration.file.YamlConfiguration
                .loadConfiguration(new java.io.File("src/main/resources/config.yml"));
        List<Long> totals = new ArrayList<>();
        for (Map<?, ?> level : config.getMapList("levels")) {
            long total = 0;
            for (Map.Entry<?, ?> resource : ((Map<?, ?>) level.get("resources")).entrySet()) {
                double price = config.getDouble("points." + resource.getKey(), config.getDouble("points.default"));
                total += ((Number) resource.getValue()).longValue() * me.panooga.snowman.logic.Points.fromConfig(price);
            }
            totals.add(total);
        }
        // Итоги этапов, посчитанные вручную для админа: 157 000 / 157 000 / 158 000
        assertEquals(List.of(15_700_000L, 15_700_000L, 15_800_000L), totals);
    }

    @Test
    void sequentialResourcesOpenInConfigOrder() {
        Map<String, Integer> required = new java.util.LinkedHashMap<>();
        required.put("snow", 10);
        required.put("carrot", 5);
        required.put("ice", 2);
        LevelProgress<String> progress = new LevelProgress<>(required);
        assertEquals("snow", progress.current());
        progress.add("snow", 9);
        assertEquals("snow", progress.current());
        progress.add("snow", 5);
        assertEquals("carrot", progress.current());
        progress.add("carrot", 5);
        progress.add("ice", 2);
        assertNull(progress.current());
        assertTrue(progress.isComplete());
    }

    @Test
    void delayIsReadInHoursAndMinutes() {
        long hour = 3_600_000L;
        long minute = 60_000L;
        assertEquals(24 * hour, me.panooga.snowman.logic.BuildSchedule.parseDelay("24h"));
        assertEquals(48 * hour, me.panooga.snowman.logic.BuildSchedule.parseDelay("48h"));
        assertEquals(90 * minute, me.panooga.snowman.logic.BuildSchedule.parseDelay("90m"));
        assertEquals(90 * minute, me.panooga.snowman.logic.BuildSchedule.parseDelay("1h 30m"));
        assertEquals(90 * minute, me.panooga.snowman.logic.BuildSchedule.parseDelay("1ч30м"));
        assertEquals(15 * minute, me.panooga.snowman.logic.BuildSchedule.parseDelay("15 min"));
        assertEquals(48 * hour, me.panooga.snowman.logic.BuildSchedule.parseDelay("2d"));
        assertEquals(24 * hour, me.panooga.snowman.logic.BuildSchedule.parseDelay("24"));
        assertEquals(30 * minute, me.panooga.snowman.logic.BuildSchedule.parseDelay("0.5h"));
        assertEquals(0, me.panooga.snowman.logic.BuildSchedule.parseDelay("0"));
        assertEquals(0, me.panooga.snowman.logic.BuildSchedule.parseDelay(""));
        assertEquals(-1, me.panooga.snowman.logic.BuildSchedule.parseDelay("сутки"));
        assertEquals(-1, me.panooga.snowman.logic.BuildSchedule.parseDelay("1h x 30m"));
    }

    @Test
    void buildIsScheduledInMoscowTime() {
        java.time.ZoneId msk = java.time.ZoneId.of("Europe/Moscow");
        java.time.LocalTime seven = java.time.LocalTime.of(19, 0);
        // Собрали 7 ноября в 23:30 МСК (20:30 UTC) — строим 8-го в 19:00 МСК
        java.time.Instant late = java.time.Instant.parse("2026-11-07T20:30:00Z");
        assertEquals(java.time.Instant.parse("2026-11-08T16:00:00Z"), me.panooga.snowman.logic.BuildSchedule.next(late, seven, msk, 1));
        // Собрали в 10:00 МСК: «завтра» — 8-го, «сегодня» — 7-го
        java.time.Instant morning = java.time.Instant.parse("2026-11-07T07:00:00Z");
        assertEquals(java.time.Instant.parse("2026-11-08T16:00:00Z"), me.panooga.snowman.logic.BuildSchedule.next(morning, seven, msk, 1));
        assertEquals(java.time.Instant.parse("2026-11-07T16:00:00Z"), me.panooga.snowman.logic.BuildSchedule.next(morning, seven, msk, 0));
        // Задержка в сутки: собрали в 03:12 МСК — строим завтра в 03:12, а не через 40 часов в 19:00
        me.panooga.snowman.config.EventConfig.Schedule day = new me.panooga.snowman.config.EventConfig.Schedule(
                true, 24 * 3_600_000L, seven, msk, 1, 10);
        java.time.Instant night = java.time.Instant.parse("2026-11-08T00:12:00Z");
        assertEquals(java.time.Instant.parse("2026-11-09T00:12:00Z"), day.buildAt(night));
        me.panooga.snowman.config.EventConfig.Schedule clock = new me.panooga.snowman.config.EventConfig.Schedule(
                true, 0, seven, msk, 1, 10);
        assertEquals(java.time.Instant.parse("2026-11-09T16:00:00Z"), clock.buildAt(night));
        // Сегодняшнее время уже прошло — тогда завтра
        assertEquals(java.time.Instant.parse("2026-11-08T16:00:00Z"), me.panooga.snowman.logic.BuildSchedule.next(late, seven, msk, 0));
    }
}
