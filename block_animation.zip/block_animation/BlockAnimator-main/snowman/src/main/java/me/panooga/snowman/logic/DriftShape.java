package me.panooga.snowman.logic;

import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * Форма сугроба — полуэллипсоид с неровным краем. Порядок блоков — порядок роста: сугроб растёт куполом
 * от центра, и под каждым блоком к моменту его появления уже есть опора.
 */
public final class DriftShape {

    private DriftShape() {
    }

    /**
     * @return смещения от центра основания (y = 0 — первый слой над землёй) в порядке роста
     */
    public static List<ImmutableVector3i> mound(int radius, int height, long seed) {
        if (radius < 1 || height < 1) {
            throw new IllegalArgumentException("Drift radius and height have to be positive");
        }
        Random random = new Random(seed);
        double outer = radius + 0.5;
        // Неровность — одна на столбец: так «оценка» растёт с высотой, и опора всегда появляется раньше
        List<Scored> scored = new ArrayList<>();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double noise = 0.85 + random.nextDouble() * 0.3;
                double radial = (dx * dx + dz * dz) / (outer * outer) * noise;
                for (int dy = 0; dy < height; dy++) {
                    double vertical = (dy + 0.5) / height;
                    double score = Math.sqrt(radial + vertical * vertical);
                    if (score <= 1) {
                        scored.add(new Scored(new ImmutableVector3i(dx, dy, dz), score));
                    }
                }
            }
        }
        scored.sort(Comparator.comparingDouble(Scored::score)
                .thenComparingInt(s -> s.offset.y())
                .thenComparingInt(s -> s.offset.x())
                .thenComparingInt(s -> s.offset.z()));
        return scored.stream().map(Scored::offset).toList();
    }


    private record Scored(ImmutableVector3i offset, double score) {
    }
}
