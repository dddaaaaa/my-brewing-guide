package me.panooga.snowman.hologram;

import me.panooga.snowman.config.EventConfig;
import me.panooga.snowman.config.Messages;
import me.panooga.snowman.logic.Contributions;
import me.panooga.snowman.logic.Points;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Голограмма у точки сдачи: общий топ вкладов, который видят все, и под ним строка «Вы сдали …» —
 * отдельный текстовый дисплей на каждого игрока, видимый только ему.
 * Дисплеи временные (не сохраняются в мир): после рестарта или выгрузки чанка они пересоздаются,
 * а не копятся дублями.
 */
public final class Leaderboard {

    // Отступ личной строки под таблицей: текст дисплея растёт вверх от его точки
    private static final double PERSONAL_OFFSET = 0.35;

    // Сюда смотрим при уборке: метка отличает наши дисплеи от голограмм других плагинов
    private static final double SWEEP_RADIUS = 4;

    private final Plugin plugin;
    private final NamespacedKey marker;
    private TextDisplay board;
    private final Map<UUID, TextDisplay> personal = new HashMap<>();
    private Location lastLocation;

    public Leaderboard(Plugin plugin) {
        this.plugin = plugin;
        this.marker = new NamespacedKey(plugin, "leaderboard");
    }

    /**
     * Раз в секунду и после каждой сдачи: создать недостающие дисплеи, обновить текст, убрать лишнее.
     *
     * @param location нижняя точка таблицы; null — голограммы нет
     * @param header   строка над таблицей (этап и прогресс)
     */
    public void update(Location location, EventConfig.Leaderboard settings, Contributions contributions, Component header) {
        if (location == null || location.getWorld() == null || !settings.enabled()) {
            remove();
            return;
        }
        if (!location.isChunkLoaded()) {
            // Ссылки не забываем: чанк выгружается не мгновенно, и забытая таблица осталась бы висеть
            // рядом с новой. Когда чанк загрузится, isValid() покажет, жива ли она
            return;
        }
        if (lastLocation != null && !sameSpot(lastLocation, location)) {
            sweep(lastLocation);
        }
        lastLocation = location.clone();
        if (board == null || !board.isValid() || !sameSpot(board.getLocation(), location)) {
            if (board != null) {
                board.remove();
            }
            sweep(location);
            board = spawn(location, settings, true);
        }
        setText(board, boardText(settings, contributions, header));

        Location personalSpot = location.clone().subtract(0, PERSONAL_OFFSET, 0);
        Set<UUID> viewers = new HashSet<>();
        double range = settings.viewDistance() * settings.viewDistance();
        for (Player player : location.getWorld().getPlayers()) {
            if (player.getLocation().distanceSquared(location) > range) {
                continue;
            }
            viewers.add(player.getUniqueId());
            TextDisplay display = personal.get(player.getUniqueId());
            if (display == null || !display.isValid() || !sameSpot(display.getLocation(), personalSpot)) {
                if (display != null) {
                    display.remove();
                }
                display = spawn(personalSpot, settings, false);
                player.showEntity(plugin, display);
                personal.put(player.getUniqueId(), display);
            }
            setText(display, personalText(contributions, player.getUniqueId()));
        }
        for (UUID id : new ArrayList<>(personal.keySet())) {
            if (!viewers.contains(id)) {
                TextDisplay display = personal.remove(id);
                if (display != null) {
                    display.remove();
                }
            }
        }
    }

    public void remove() {
        if (board != null) {
            board.remove();
            board = null;
        }
        personal.values().forEach(TextDisplay::remove);
        personal.clear();
        if (lastLocation != null) {
            sweep(lastLocation);
            lastLocation = null;
        }
    }

    /**
     * Убирает все наши дисплеи около точки, кроме тех, что сейчас в работе: дубли могли остаться
     * от прерванного обновления или выгрузки чанка.
     */
    private void sweep(Location around) {
        if (around.getWorld() == null || !around.isChunkLoaded()) {
            return;
        }
        for (TextDisplay display : around.getWorld().getNearbyEntitiesByType(TextDisplay.class, around, SWEEP_RADIUS)) {
            if (display.getPersistentDataContainer().has(marker, PersistentDataType.BYTE)
                    && display != board && !personal.containsValue(display)) {
                display.remove();
            }
        }
    }

    private Component boardText(EventConfig.Leaderboard settings, Contributions contributions, Component header) {
        List<Component> lines = new ArrayList<>();
        lines.add(Messages.get("leaderboard-title"));
        lines.add(header);
        List<Contributions.Entry> ranking = contributions.ranking();
        if (ranking.isEmpty()) {
            lines.add(Messages.get("leaderboard-empty"));
        }
        for (int i = 0; i < Math.min(settings.size(), ranking.size()); i++) {
            Contributions.Entry entry = ranking.get(i);
            lines.add(Messages.get(i < 3 ? "leaderboard-line-top" : "leaderboard-line",
                    "place", i + 1, "player", entry.name(), "points", Points.format(entry.points()), "items", entry.items()));
        }
        return Component.join(JoinConfiguration.newlines(), lines);
    }

    private static Component personalText(Contributions contributions, UUID id) {
        return contributions.get(id)
                .filter(entry -> entry.points() > 0)
                .map(entry -> Messages.get("leaderboard-self", "points", Points.format(entry.points()), "items", entry.items(), "place", contributions.place(id)))
                .orElseGet(() -> Messages.get("leaderboard-self-empty"));
    }

    private TextDisplay spawn(Location location, EventConfig.Leaderboard settings, boolean visibleToAll) {
        return location.getWorld().spawn(location, TextDisplay.class, display -> {
            display.setPersistent(false);
            // Неподвижная табличка: поворот берётся из location (лицевая сторона смотрит по yaw)
            display.setBillboard(Display.Billboard.FIXED);
            display.setAlignment(TextDisplay.TextAlignment.CENTER);
            display.setShadowed(true);
            display.setLineWidth(300);
            display.setViewRange((float) Math.max(0.1, settings.viewDistance() / 64.0));
            if (settings.background()) {
                display.setBackgroundColor(Color.fromARGB(110, 10, 30, 50));
            } else {
                display.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            }
            // Личную строку видит только её владелец: остальным её сразу не отправляют вовсе
            display.setVisibleByDefault(visibleToAll);
            display.getPersistentDataContainer().set(marker, PersistentDataType.BYTE, (byte) 1);
        });
    }

    /**
     * Текст шлётся клиентам при каждой установке — не трогаем дисплей, если ничего не поменялось.
     */
    private static void setText(TextDisplay display, Component text) {
        if (!text.equals(display.text())) {
            display.text(text);
        }
    }

    private static boolean sameSpot(Location a, Location b) {
        return a.getWorld() == b.getWorld() && a.distanceSquared(b) < 0.01
                && Math.abs(Location.normalizeYaw(a.getYaw() - b.getYaw())) < 0.5;
    }

    /**
     * Игрок вышел — его личный дисплей больше не нужен.
     */
    public void forget(UUID id) {
        TextDisplay display = personal.remove(id);
        if (display != null) {
            display.remove();
        }
    }
}
