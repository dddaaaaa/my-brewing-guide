package me.panooga.snowman.logic;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Сколько чего нужно на уровень и сколько уже сдано. Ресурс сверх нормы не принимается —
 * иначе игрок «сдал» бы предметы, которые ни на что не пошли.
 */
public final class LevelProgress<K> {

    private final Map<K, Integer> required;
    private final Map<K, Integer> donated = new LinkedHashMap<>();

    public LevelProgress(Map<K, Integer> required) {
        this.required = Collections.unmodifiableMap(new LinkedHashMap<>(required));
    }

    public Map<K, Integer> required() {
        return required;
    }

    public int donated(K resource) {
        return donated.getOrDefault(resource, 0);
    }

    public int remaining(K resource) {
        return Math.max(0, required.getOrDefault(resource, 0) - donated(resource));
    }

    /**
     * @return сколько принято (не больше остатка)
     */
    public int add(K resource, int amount) {
        int accepted = Math.min(Math.max(0, amount), remaining(resource));
        if (accepted > 0) {
            donated.merge(resource, accepted, Integer::sum);
        }
        return accepted;
    }

    /**
     * Восстановление из файла: лишнее и чужие ресурсы отбрасываются, если норму уровня поменяли в конфиге.
     */
    public void restore(K resource, int amount) {
        if (required.containsKey(resource)) {
            donated.put(resource, Math.min(Math.max(0, amount), required.get(resource)));
        }
    }

    public Map<K, Integer> donatedView() {
        return Collections.unmodifiableMap(donated);
    }

    public double fraction() {
        long total = 0;
        long done = 0;
        for (Map.Entry<K, Integer> entry : required.entrySet()) {
            total += entry.getValue();
            done += Math.min(entry.getValue(), donated(entry.getKey()));
        }
        return total == 0 ? 1 : (double) done / total;
    }

    public boolean isComplete() {
        return required.keySet().stream().allMatch(resource -> remaining(resource) == 0);
    }

    /**
     * Ресурс, который сейчас собирают при поочерёдной сдаче: первый по порядку из конфига, которого ещё не хватает.
     * null — всё собрано.
     */
    public K current() {
        for (K resource : required.keySet()) {
            if (remaining(resource) > 0) {
                return resource;
            }
        }
        return null;
    }

    public void fillAll() {
        required.forEach(donated::put);
    }
}
