package me.panooga.snowman.event;

import me.panooga.snowman.config.EventConfig;
import me.panooga.snowman.config.Messages;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Выдача наград командами из консоли. Тем, кто не в сети, награда откладывается до входа: хранится вид награды,
 * а не готовые команды, поэтому исправленный в конфиге список команд применится и к отложенным.
 */
final class Rewards {

    static final String TOP = "top";
    static final String COMPLETION = "completion";

    private final Supplier<EventConfig> config;
    private final Map<UUID, List<String>> pending = new LinkedHashMap<>();

    Rewards(Supplier<EventConfig> config) {
        this.config = config;
    }

    void grant(UUID id, List<String> kinds) {
        Player player = Bukkit.getPlayer(id);
        if (player != null) {
            give(player, kinds);
        } else {
            pending.computeIfAbsent(id, ignored -> new ArrayList<>()).addAll(kinds);
        }
    }

    /**
     * @return была ли отложенная награда
     */
    boolean deliverPending(Player player) {
        List<String> kinds = pending.remove(player.getUniqueId());
        if (kinds == null || kinds.isEmpty()) {
            return false;
        }
        give(player, kinds);
        return true;
    }

    private void give(Player player, List<String> kinds) {
        for (String kind : kinds) {
            List<String> commands = kind.equals(TOP) ? config.get().topRewards() : config.get().completionRewards();
            for (String command : commands) {
                String line = command.startsWith("/") ? command.substring(1) : command;
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), line.replace("%player%", player.getName()));
            }
            Messages.send(player, kind.equals(TOP) ? "reward-top" : "reward-completion");
        }
    }

    void load(ConfigurationSection section) {
        pending.clear();
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            try {
                pending.put(UUID.fromString(key), new ArrayList<>(section.getStringList(key)));
            } catch (IllegalArgumentException ignored) {
                // Повреждённая запись — пропускаем, остальные награды не теряем
            }
        }
    }

    void save(ConfigurationSection section) {
        pending.forEach((id, kinds) -> section.set(id.toString(), kinds));
    }
}
