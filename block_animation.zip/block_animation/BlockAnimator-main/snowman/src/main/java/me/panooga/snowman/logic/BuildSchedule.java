package me.panooga.snowman.logic;

import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/**
 * Когда строить собранный этап. Время считается в часовом поясе ивента (по умолчанию МСК), а не сервера:
 * хостинг может стоять в другой зоне, а игрокам обещают «завтра в 19:00 по Москве».
 */
public final class BuildSchedule {

    private BuildSchedule() {
    }

    /**
     * Задержка из конфига: «24h», «48h», «90m», «1h 30m», «2d», можно по-русски — «24ч», «90м», «2д».
     * Число без единиц — часы.
     *
     * @return миллисекунды; 0 — пусто или «0» (режим «в заданное время»); -1 — не разобрать
     */
    public static long parseDelay(String text) {
        if (text == null || text.isBlank()) {
            return 0;
        }
        String value = text.trim().toLowerCase(java.util.Locale.ROOT).replace(',', '.');
        if (value.matches("\\d+(\\.\\d+)?")) {
            return Math.round(Double.parseDouble(value) * 3_600_000);
        }
        java.util.regex.Matcher part = java.util.regex.Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(мин|min|d|д|h|ч|m|м)").matcher(value);
        long total = 0;
        int end = 0;
        while (part.find()) {
            // Между частями допускаются только пробелы: «1h x 30m» — опечатка, а не 1,5 часа
            if (!value.substring(end, part.start()).isBlank()) {
                return -1;
            }
            double amount = Double.parseDouble(part.group(1));
            long unit = switch (part.group(2)) {
                case "d", "д" -> 86_400_000L;
                case "h", "ч" -> 3_600_000L;
                default -> 60_000L;
            };
            total += Math.round(amount * unit);
            end = part.end();
        }
        return end == 0 || !value.substring(end).isBlank() ? -1 : total;
    }

    /**
     * @param daysAfter 1 — завтра в это время; 0 — сегодня, а если время уже прошло, то завтра
     */
    public static Instant next(Instant collectedAt, LocalTime time, ZoneId zone, int daysAfter) {
        ZonedDateTime now = collectedAt.atZone(zone);
        ZonedDateTime at = now.toLocalDate().plusDays(Math.max(0, daysAfter)).atTime(time).atZone(zone);
        while (!at.toInstant().isAfter(collectedAt)) {
            at = at.plusDays(1);
        }
        return at.toInstant();
    }
}
