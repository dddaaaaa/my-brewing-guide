package me.panooga.snowman.config;

import me.panooga.snowman.logic.BuildSchedule;
import me.panooga.snowman.logic.Points;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Настройки из config.yml. Ошибки не роняют загрузку: значение заменяется разумным и попадает в список
 * предупреждений, которые плагин пишет в консоль.
 */
public record EventConfig(
        String schematic,
        int rotation,
        int nearbyRadius,
        int bossbarRadius,
        double donationRadius,
        List<LevelSpec> levels,
        long defaultPoints,
        Map<Material, Long> points,
        Drift drift,
        Animation animation,
        Leaderboard leaderboard,
        List<String> topRewards,
        List<String> completionRewards,
        boolean rewardNearbySpectators,
        boolean sequentialResources,
        Schedule schedule,
        Flight flight,
        Celebration celebration
) {

    public record LevelSpec(String name, int heightPercent, Map<Material, Integer> resources) {
    }

    public record Drift(Material material, char axis, int gap, int radius, int height) {
    }

    public record Animation(int durationTicks, String order, double speed, double arcHeight, float flyScale,
                            double growStart, double spinTurns, int updateInterval, boolean effects) {
    }

    public record Leaderboard(boolean enabled, int size, double viewDistance, boolean background) {
    }

    /**
     * @param delayMillis через сколько после сбора строить; 0 — не по задержке, а в {@code time}
     * @param time        время постройки по часам (режим «в заданное время»)
     */
    public record Schedule(boolean enabled, long delayMillis, LocalTime time, ZoneId zone, int daysAfter, int countdownSeconds) {

        /**
         * Когда строить этап, собранный в {@code collectedAt}.
         */
        public Instant buildAt(Instant collectedAt) {
            return delayMillis > 0
                    ? collectedAt.plusMillis(delayMillis)
                    : BuildSchedule.next(collectedAt, time, zone, daysAfter);
        }
    }

    /**
     * Салют после постройки: волны ракет в разные стороны и на разную высоту.
     */
    public record Celebration(int waves, int waveIntervalTicks, int firstWave, int waveGrowth, double spread) {
    }

    public record Flight(boolean enabled, int maxBlocks, int durationTicks, double arcHeight, float scale) {
    }

    /**
     * @return очки за штуку в сотых
     */
    public long pointsFor(Material material) {
        return points.getOrDefault(material, defaultPoints);
    }

    public static EventConfig load(FileConfiguration config, Consumer<String> warn) {
        int rotation = config.getInt("rotation", 0);
        if (rotation % 90 != 0) {
            warn.accept("rotation должен быть кратен 90, взято 0");
            rotation = 0;
        }
        rotation = Math.floorMod(rotation, 360);

        List<LevelSpec> levels = new ArrayList<>();
        int previousPercent = 0;
        for (Map<?, ?> raw : config.getMapList("levels")) {
            String name = String.valueOf(raw.containsKey("name") ? raw.get("name") : "Уровень " + (levels.size() + 1));
            int percent = raw.get("height-percent") instanceof Number number ? number.intValue() : 100;
            if (percent <= previousPercent || percent > 100) {
                warn.accept("уровень «" + name + "»: height-percent должен расти от уровня к уровню и быть не больше 100");
                percent = Math.min(100, previousPercent + 1);
            }
            previousPercent = percent;
            Map<Material, Integer> resources = new LinkedHashMap<>();
            if (raw.get("resources") instanceof Map<?, ?> resourceMap) {
                resourceMap.forEach((key, value) -> {
                    Material material = item(String.valueOf(key), warn);
                    int amount = value instanceof Number number ? number.intValue() : 0;
                    if (material != null && amount > 0) {
                        resources.merge(material, amount, Integer::sum);
                    } else if (material != null) {
                        warn.accept("уровень «" + name + "»: у " + key + " количество должно быть больше нуля");
                    }
                });
            }
            if (resources.isEmpty()) {
                warn.accept("уровень «" + name + "» без ресурсов — он завершится сразу после начала");
            }
            levels.add(new LevelSpec(name, percent, resources));
        }
        if (levels.isEmpty()) {
            warn.accept("в levels нет ни одного уровня — добавлен один уровень без ресурсов");
            levels.add(new LevelSpec("Снеговик", 100, Map.of()));
        }

        // Очки в сотых (см. Points): в конфиге можно писать 0.1, 0.5, 1.2
        long defaultPoints = Points.SCALE;
        Map<Material, Long> points = new LinkedHashMap<>();
        ConfigurationSection pointsSection = config.getConfigurationSection("points");
        if (pointsSection != null) {
            for (String key : pointsSection.getKeys(false)) {
                if (key.equalsIgnoreCase("default")) {
                    defaultPoints = Points.fromConfig(pointsSection.getDouble(key, 1));
                    continue;
                }
                Material material = item(key, warn);
                if (material != null) {
                    points.put(material, Points.fromConfig(pointsSection.getDouble(key, 1)));
                }
            }
        }

        Material driftMaterial = block(config.getString("drifts.material", "snow_block"), warn);
        String axisValue = config.getString("drifts.axis", "x").toLowerCase(Locale.ROOT);
        char axis = axisValue.equals("z") ? 'z' : 'x';
        Drift drift = new Drift(driftMaterial == null ? Material.SNOW_BLOCK : driftMaterial, axis,
                Math.max(0, config.getInt("drifts.gap", 3)),
                clamp(config.getInt("drifts.radius", 4), 1, 16, "drifts.radius", warn),
                clamp(config.getInt("drifts.height", 3), 1, 16, "drifts.height", warn));

        double growStart = config.getDouble("animation.grow-start", 0.9);
        if (growStart < 0 || growStart >= 1) {
            warn.accept("animation.grow-start должен быть от 0 до 0.99, взято 0.9");
            growStart = 0.9;
        }
        Animation animation = new Animation(
                Math.max(1, config.getInt("animation.duration-ticks", 200)),
                config.getString("animation.order", "layered").toLowerCase(Locale.ROOT),
                Math.max(0.05, config.getDouble("animation.speed", 0.35)),
                Math.max(0, config.getDouble("animation.arc-height", 6)),
                (float) Math.max(0.05, Math.min(1, config.getDouble("animation.fly-scale", 0.45))),
                growStart,
                config.getDouble("animation.spin-turns", 1),
                clamp(config.getInt("animation.update-interval", 2), 1, 59, "animation.update-interval", warn),
                config.getBoolean("animation.effects", true));

        return new EventConfig(
                config.getString("schematic", "builtin"),
                rotation,
                Math.max(1, config.getInt("nearby-radius", 64)),
                // В старых конфигах ключа нет — тогда полоса видна там же, где и раньше
                Math.max(1, config.getInt("bossbar-radius", config.getInt("nearby-radius", 64))),
                Math.max(1, config.getDouble("donation-radius", 6)),
                List.copyOf(levels),
                defaultPoints,
                Map.copyOf(points),
                drift,
                animation,
                new Leaderboard(
                        config.getBoolean("leaderboard.enabled", true),
                        clamp(config.getInt("leaderboard.size", 10), 1, 20, "leaderboard.size", warn),
                        Math.max(4, config.getDouble("leaderboard.view-distance", 20)),
                        config.getBoolean("leaderboard.background", true)),
                config.getStringList("rewards.top"),
                config.getStringList("rewards.completion"),
                config.getBoolean("rewards.include-nearby-spectators", false),
                config.getBoolean("sequential-resources", true),
                schedule(config, warn),
                new Flight(
                        config.getBoolean("donation-flight.enabled", true),
                        clamp(config.getInt("donation-flight.max-blocks", 6), 1, 32, "donation-flight.max-blocks", warn),
                        clamp(config.getInt("donation-flight.duration-ticks", 30), 5, 200, "donation-flight.duration-ticks", warn),
                        Math.max(0, config.getDouble("donation-flight.arc-height", 3)),
                        (float) Math.max(0.1, Math.min(1, config.getDouble("donation-flight.scale", 0.45)))),
                new Celebration(
                        clamp(config.getInt("celebration.waves", 5), 1, 20, "celebration.waves", warn),
                        clamp(config.getInt("celebration.wave-interval-ticks", 60), 5, 400, "celebration.wave-interval-ticks", warn),
                        // per-wave — название из прошлой версии конфига
                        clamp(config.getInt("celebration.first-wave", config.getInt("celebration.per-wave", 8)), 1, 60, "celebration.first-wave", warn),
                        clamp(config.getInt("celebration.wave-growth", 4), 0, 30, "celebration.wave-growth", warn),
                        Math.max(1, Math.min(40, config.getDouble("celebration.spread", 16)))));
    }

    private static Schedule schedule(FileConfiguration config, Consumer<String> warn) {
        ZoneId zone;
        String zoneName = config.getString("schedule.timezone", "Europe/Moscow");
        try {
            zone = ZoneId.of(zoneName);
        } catch (DateTimeException e) {
            warn.accept("schedule.timezone: неизвестный часовой пояс «" + zoneName + "», взят Europe/Moscow");
            zone = ZoneId.of("Europe/Moscow");
        }
        LocalTime time = LocalTime.of(19, 0);
        String value = config.getString("schedule.time", "19:00");
        try {
            time = LocalTime.parse(value.length() == 4 ? "0" + value : value);
        } catch (DateTimeParseException e) {
            warn.accept("schedule.time должен быть в виде ЧЧ:ММ, например 19:00 — взято 19:00");
        }
        // delay — «24h», «90m»; delay-hours — числом из прошлой версии. Нет ни того, ни другого
        // (старый конфиг) — прежний режим «в заданное время»
        long delay;
        if (config.isSet("schedule.delay")) {
            String delayText = config.getString("schedule.delay", "");
            delay = BuildSchedule.parseDelay(delayText);
            if (delay < 0) {
                warn.accept("schedule.delay: не понял «" + delayText + "» — пишите 24h, 48h, 90m или 1h 30m; взято 24h");
                delay = 24 * 3_600_000L;
            }
        } else {
            delay = Math.max(0, Math.round(config.getDouble("schedule.delay-hours", 0) * 3_600_000));
        }
        return new Schedule(config.getBoolean("schedule.enabled", false), delay, time, zone,
                clamp(config.getInt("schedule.days-after", 1), 0, 30, "schedule.days-after", warn),
                clamp(config.getInt("schedule.countdown-seconds", 10), 0, 300, "schedule.countdown-seconds", warn));
    }

    private static Material item(String key, Consumer<String> warn) {
        Material material = Material.matchMaterial(key);
        if (material == null || !material.isItem() || material.isAir()) {
            warn.accept("неизвестный предмет «" + key + "» — пропущен");
            return null;
        }
        return material;
    }

    private static Material block(String key, Consumer<String> warn) {
        Material material = Material.matchMaterial(key);
        if (material == null || !material.isBlock() || material.isAir()) {
            warn.accept("неизвестный блок «" + key + "» — взят snow_block");
            return null;
        }
        return material;
    }

    private static int clamp(int value, int min, int max, String path, Consumer<String> warn) {
        if (value < min || value > max) {
            warn.accept(path + " должен быть от " + min + " до " + max);
            return Math.max(min, Math.min(max, value));
        }
        return value;
    }
}
