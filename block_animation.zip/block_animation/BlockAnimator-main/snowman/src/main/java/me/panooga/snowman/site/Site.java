package me.panooga.snowman.site;

import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import me.panooga.snowman.config.EventConfig;
import me.panooga.snowman.logic.LevelPlan;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Постройка в мировых координатах: какой блок где стоит и какие блоки относятся к какому уровню.
 * Блоки ставим сами через setBlockData — для снеговика не нужны данные сундуков и табличек,
 * зато WorldEdit требуется только для чтения своей схематики.
 */
public final class Site {

    private final World world;
    private final Map<ImmutableVector3i, BlockData> blocks;
    private final List<List<ImmutableVector3i>> levels;
    private final int minX, maxX, minY, maxY, minZ, maxZ;

    private Site(World world, Map<ImmutableVector3i, BlockData> blocks, List<Integer> heightPercents) {
        this.world = world;
        this.blocks = Collections.unmodifiableMap(blocks);
        List<List<ImmutableVector3i>> split = LevelPlan.split(blocks.keySet(), heightPercents);
        List<List<ImmutableVector3i>> immutable = new ArrayList<>();
        split.forEach(level -> immutable.add(List.copyOf(level)));
        this.levels = List.copyOf(immutable);
        int x0 = Integer.MAX_VALUE, x1 = Integer.MIN_VALUE, y0 = Integer.MAX_VALUE, y1 = Integer.MIN_VALUE, z0 = Integer.MAX_VALUE, z1 = Integer.MIN_VALUE;
        for (ImmutableVector3i position : blocks.keySet()) {
            x0 = Math.min(x0, position.x());
            x1 = Math.max(x1, position.x());
            y0 = Math.min(y0, position.y());
            y1 = Math.max(y1, position.y());
            z0 = Math.min(z0, position.z());
            z1 = Math.max(z1, position.z());
        }
        this.minX = x0;
        this.maxX = x1;
        this.minY = y0;
        this.maxY = y1;
        this.minZ = z0;
        this.maxZ = z1;
    }

    public static Site load(Plugin plugin, EventConfig config, Location origin) throws SiteException {
        World world = origin.getWorld();
        if (world == null) {
            throw new SiteException("site-no-world");
        }
        Map<ImmutableVector3i, BlockData> blocks = new LinkedHashMap<>();
        String schematic = config.schematic();
        if (schematic.equalsIgnoreCase("builtin")) {
            ImmutableVector3i base = new ImmutableVector3i(origin.getBlockX(), origin.getBlockY(), origin.getBlockZ());
            BuiltinSnowman.generate(config.rotation()).forEach((offset, material) -> blocks.put(base.add(offset), material.createBlockData()));
        } else {
            if (!Bukkit.getPluginManager().isPluginEnabled("WorldEdit") && !Bukkit.getPluginManager().isPluginEnabled("FastAsyncWorldEdit")) {
                throw new SiteException("site-no-worldedit");
            }
            File file = new File(new File(plugin.getDataFolder(), "schematics"), schematic);
            if (!file.isFile()) {
                throw new SiteException("site-no-file", "file", file.getName());
            }
            try {
                blocks.putAll(SchematicLoader.load(file, origin, config.rotation()));
            } catch (Exception e) {
                plugin.getLogger().warning("Не удалось прочитать схематику " + file.getName() + ": " + e);
                throw new SiteException("site-bad-file", "file", file.getName());
            }
        }
        blocks.values().removeIf(data -> data.getMaterial().isAir());
        if (blocks.isEmpty()) {
            throw new SiteException("site-empty");
        }
        List<Integer> percents = config.levels().stream().map(EventConfig.LevelSpec::heightPercent).toList();
        return new Site(world, blocks, percents);
    }

    public World world() {
        return world;
    }

    public int levelCount() {
        return levels.size();
    }

    public List<ImmutableVector3i> level(int index) {
        return levels.get(index);
    }

    public BlockData blockAt(ImmutableVector3i position) {
        return blocks.get(position);
    }

    public Map<ImmutableVector3i, BlockData> blocks() {
        return blocks;
    }

    public void place(ImmutableVector3i position) {
        BlockData data = blocks.get(position);
        if (data != null) {
            // Без физики: снег и ограды не должны пересчитывать соседей на каждый из сотен блоков
            world.getBlockAt(position.x(), position.y(), position.z()).setBlockData(data, false);
        }
    }

    public void clear(ImmutableVector3i position) {
        world.getBlockAt(position.x(), position.y(), position.z()).setType(Material.AIR, false);
    }

    public int minX() {
        return minX;
    }

    public int maxX() {
        return maxX;
    }

    public int minY() {
        return minY;
    }

    public int maxY() {
        return maxY;
    }

    public int minZ() {
        return minZ;
    }

    public int maxZ() {
        return maxZ;
    }

    public Location top() {
        return new Location(world, (minX + maxX + 1) / 2.0, maxY + 1.5, (minZ + maxZ + 1) / 2.0);
    }

    public Location center() {
        return new Location(world, (minX + maxX + 1) / 2.0, (minY + maxY + 1) / 2.0, (minZ + maxZ + 1) / 2.0);
    }

    /**
     * Ошибка загрузки с ключом сообщения из messages.yml.
     */
    public static final class SiteException extends Exception {
        private final String messageKey;
        private final Object[] placeholders;

        public SiteException(String messageKey, Object... placeholders) {
            super(messageKey);
            this.messageKey = messageKey;
            this.placeholders = placeholders;
        }

        public String messageKey() {
            return messageKey;
        }

        public Object[] placeholders() {
            return placeholders;
        }
    }
}
