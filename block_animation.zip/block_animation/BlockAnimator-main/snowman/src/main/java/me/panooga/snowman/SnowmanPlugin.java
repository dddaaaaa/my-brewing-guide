package me.panooga.snowman;

import me.panooga.snowman.command.SnowmanCommand;
import me.panooga.snowman.config.EventConfig;
import me.panooga.snowman.config.Messages;
import me.panooga.snowman.event.SnowmanEvent;
import me.panooga.snowman.gui.EventListener;
import me.panooga.snowman.storage.DataStore;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public final class SnowmanPlugin extends JavaPlugin {

    private SnowmanEvent event;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        new File(getDataFolder(), "schematics").mkdirs();
        Messages.load(this);
        event = new SnowmanEvent(this, new DataStore(this));
        event.load(loadConfig());

        SnowmanCommand command = new SnowmanCommand(this, event);
        PluginCommand registered = getCommand("snowman");
        if (registered != null) {
            registered.setExecutor(command);
            registered.setTabCompleter(command);
        }
        getServer().getPluginManager().registerEvents(new EventListener(this, event), this);
        getServer().getScheduler().runTaskTimer(this, event::tickBar, 20, 20);
        // Сдача помечает данные изменёнными, а на диск они уходят не чаще раза в 5 секунд
        getServer().getScheduler().runTaskTimer(this, event::saveIfDirty, 100, 100);
        getLogger().info("Ивент: " + event.state() + ", уровень " + (event.level() + 1) + "/" + event.config().levels().size());
    }

    @Override
    public void onDisable() {
        if (event != null) {
            event.shutdown();
        }
    }

    /**
     * @return false, если сейчас идёт постройка уровня и конфиг применить нельзя
     */
    public boolean reload() {
        reloadConfig();
        Messages.load(this);
        return event.reload(loadConfig());
    }

    private EventConfig loadConfig() {
        return EventConfig.load(getConfig(), warning -> getLogger().warning("config.yml: " + warning));
    }
}
