package me.panooga.snowman.config;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Все тексты плагина — в messages.yml (MiniMessage). В коде: {@code Messages.send(игрок, "ключ", "имя", значение)}.
 * Ключ, которого нет в файле админа, берётся из файла внутри jar — новые сообщения работают и после обновления.
 */
public final class Messages {

    private static final MiniMessage MINI = MiniMessage.miniMessage();
    private static YamlConfiguration messages = new YamlConfiguration();

    private Messages() {
    }

    public static void load(JavaPlugin plugin) {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        YamlConfiguration loaded = YamlConfiguration.loadConfiguration(file);
        InputStream bundled = plugin.getResource("messages.yml");
        if (bundled != null) {
            loaded.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(bundled, StandardCharsets.UTF_8)));
        }
        messages = loaded;
    }

    public static Component get(String key, Object... placeholders) {
        return MINI.deserialize(raw(key), resolver(placeholders));
    }

    /**
     * Для названий и описаний предметов: без курсива, который Minecraft ставит на свои надписи по умолчанию.
     */
    public static Component item(String key, Object... placeholders) {
        return plain(get(key, placeholders));
    }

    public static List<Component> lore(String key, Object... placeholders) {
        List<Component> output = new ArrayList<>();
        TagResolver resolver = resolver(placeholders);
        for (String line : messages.getStringList(key)) {
            output.add(plain(MINI.deserialize(line, resolver)));
        }
        return output;
    }

    public static void send(CommandSender receiver, String key, Object... placeholders) {
        receiver.sendMessage(prefixed(key, placeholders));
    }

    public static void broadcast(String key, Object... placeholders) {
        Bukkit.getServer().sendMessage(prefixed(key, placeholders));
    }

    public static String raw(String key) {
        String value = messages.getString(key);
        return value == null ? key : value;
    }

    private static Component prefixed(String key, Object... placeholders) {
        return get("prefix").append(get(key, placeholders));
    }

    private static Component plain(Component component) {
        return component.decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    private static TagResolver resolver(Object... placeholders) {
        if (placeholders.length % 2 != 0) {
            throw new IllegalArgumentException("Placeholders come in name-value pairs");
        }
        TagResolver.Builder builder = TagResolver.builder();
        for (int i = 0; i < placeholders.length; i += 2) {
            String name = String.valueOf(placeholders[i]);
            Object value = placeholders[i + 1];
            if (value instanceof Component component) {
                builder.resolver(Placeholder.component(name, component));
            } else {
                builder.resolver(Placeholder.parsed(name, String.valueOf(value)));
            }
        }
        return builder.build();
    }
}
