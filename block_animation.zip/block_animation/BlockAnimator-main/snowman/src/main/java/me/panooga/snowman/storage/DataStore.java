package me.panooga.snowman.storage;

import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;

/**
 * data.yml — состояние ивента, вклады и невыданные награды; backup.yml — что стояло на месте постройки до начала.
 * Текст файла собирается в основном потоке, на диск пишется в отдельном: сдача ресурсов не ждёт диска.
 * Запись идёт через временный файл, чтобы сбой посреди записи не оставил обрезанный data.yml.
 */
public final class DataStore {

    private final Plugin plugin;
    private final File dataFile;
    private final File backupFile;
    private final Object writeLock = new Object();

    public DataStore(Plugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
        this.backupFile = new File(plugin.getDataFolder(), "backup.yml");
    }

    public YamlConfiguration loadData() {
        return YamlConfiguration.loadConfiguration(dataFile);
    }

    public void saveData(YamlConfiguration data, boolean async) {
        write(dataFile, data.saveToString(), async);
    }

    public Map<ImmutableVector3i, String> loadBackup() {
        Map<ImmutableVector3i, String> output = new LinkedHashMap<>();
        if (!backupFile.isFile()) {
            return output;
        }
        for (String line : YamlConfiguration.loadConfiguration(backupFile).getStringList("blocks")) {
            int space = line.indexOf(' ');
            ImmutableVector3i position = space < 0 ? null : parsePosition(line.substring(0, space));
            if (position != null) {
                output.put(position, line.substring(space + 1));
            }
        }
        return output;
    }

    public void saveBackup(Map<ImmutableVector3i, String> blocks) {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("blocks", blocks.entrySet().stream().map(entry -> formatPosition(entry.getKey()) + " " + entry.getValue()).toList());
        write(backupFile, yaml.saveToString(), false);
    }

    public void deleteBackup() {
        synchronized (writeLock) {
            if (backupFile.exists() && !backupFile.delete()) {
                plugin.getLogger().warning("Не удалось удалить backup.yml");
            }
        }
    }

    private void write(File file, String content, boolean async) {
        Runnable task = () -> {
            synchronized (writeLock) {
                try {
                    Files.createDirectories(file.getParentFile().toPath());
                    Path temp = file.toPath().resolveSibling(file.getName() + ".tmp");
                    Files.writeString(temp, content, StandardCharsets.UTF_8);
                    Files.move(temp, file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (IOException e) {
                    plugin.getLogger().log(Level.SEVERE, "Не удалось сохранить " + file.getName(), e);
                }
            }
        };
        if (async && plugin.isEnabled()) {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, task);
        } else {
            task.run();
        }
    }

    public static String formatPosition(ImmutableVector3i position) {
        return position.x() + "," + position.y() + "," + position.z();
    }

    public static ImmutableVector3i parsePosition(String value) {
        String[] parts = value.split(",");
        if (parts.length != 3) {
            return null;
        }
        try {
            return new ImmutableVector3i(Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim()), Integer.parseInt(parts[2].trim()));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static void setLocation(ConfigurationSection section, String path, Location location) {
        if (location == null || location.getWorld() == null) {
            section.set(path, null);
            return;
        }
        section.set(path + ".world", location.getWorld().getName());
        section.set(path + ".x", location.getBlockX());
        section.set(path + ".y", location.getBlockY());
        section.set(path + ".z", location.getBlockZ());
    }

    /**
     * С дробными координатами — для голограммы, которую ставят не по сетке блоков, а там, где стоит админ.
     */
    public static void setPreciseLocation(ConfigurationSection section, String path, Location location) {
        if (location == null || location.getWorld() == null) {
            section.set(path, null);
            return;
        }
        section.set(path + ".world", location.getWorld().getName());
        section.set(path + ".x", location.getX());
        section.set(path + ".y", location.getY());
        section.set(path + ".z", location.getZ());
        section.set(path + ".yaw", (double) location.getYaw());
    }

    public static Location getPreciseLocation(ConfigurationSection section, String path) {
        String worldName = section.getString(path + ".world");
        World world = worldName == null ? null : Bukkit.getWorld(worldName);
        if (world == null) {
            return null;
        }
        return new Location(world, section.getDouble(path + ".x"), section.getDouble(path + ".y"), section.getDouble(path + ".z"),
                (float) section.getDouble(path + ".yaw"), 0);
    }

    public static Location getLocation(ConfigurationSection section, String path) {
        String worldName = section.getString(path + ".world");
        World world = worldName == null ? null : Bukkit.getWorld(worldName);
        if (world == null) {
            return null;
        }
        return new Location(world, section.getInt(path + ".x"), section.getInt(path + ".y"), section.getInt(path + ".z"));
    }

}
