package me.panooga.snowman.event;

import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import me.panooga.snowman.SnowmanPlugin;
import me.panooga.snowman.build.DonationFlights;
import me.panooga.snowman.build.DriftManager;

import me.panooga.snowman.build.LevelBuild;
import me.panooga.snowman.config.EventConfig;
import me.panooga.snowman.config.Messages;
import me.panooga.snowman.gui.DonateMenu;
import me.panooga.snowman.hologram.Leaderboard;
import me.panooga.snowman.logic.Contributions;
import me.panooga.snowman.logic.Points;
import me.panooga.snowman.logic.LevelProgress;
import me.panooga.snowman.site.Site;
import me.panooga.snowman.storage.DataStore;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.persistence.PersistentDataType;

import java.time.Duration;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Ход ивента. IDLE → (start) → COLLECTING уровень 1 → норма собрана → [WAITING до назначенного времени, таймер] →
 * BUILDING → COLLECTING уровень 2 → … → FINISHED (награды выданы). Всё состояние живёт здесь и сохраняется в data.yml.
 */
public final class SnowmanEvent {

    public enum State {
        IDLE, COLLECTING, WAITING, BUILDING, FINISHED
    }

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM");

    private final SnowmanPlugin plugin;
    private final DataStore store;
    private final Rewards rewards;
    private final NamespacedKey fireworkKey;
    private final BossBar bar = BossBar.bossBar(Component.empty(), 0, BossBar.Color.WHITE, BossBar.Overlay.NOTCHED_10);
    private final Set<UUID> barViewers = new HashSet<>();
    private final Contributions contributions = new Contributions();
    private EventConfig config;
    private State state = State.IDLE;
    private int level;
    private LevelProgress<Material> progress;
    private Location origin;
    private Location donation;
    // Центры сугробов, заданные админом; null — сугроб ставится сам по бокам от постройки
    private final Location[] driftPoints = new Location[2];
    private final Leaderboard leaderboard;
    // Низ голограммы; null — над точкой сдачи
    private Location leaderboardPoint;
    private Site site;
    private Site.SiteException siteError;
    private DriftManager drift;
    // Сугробы из data.yml, если постройку загрузить не удалось: без этого их запись пропала бы при сохранении
    private Map<ImmutableVector3i, String> orphanDrift = Map.of();
    private LevelBuild build;
    private boolean dirty;
    // Когда начнётся постройка собранного этапа (WAITING), мс с эпохи
    private long buildAt;
    // Когда собрали ресурсы этапа: от этого момента считается задержка, и по нему же время пересчитывается при reload
    private long collectedAt;
    // Админ запустил постройку сразу (skip) — reload не должен возвращать назначенное время
    private boolean buildForced;
    private final DonationFlights flights;
    // Сколько сдач ещё летит в сугробы: пока летят, сугроб не дорастает — снег появляется, когда ресурсы долетели
    private int flightsInAir;

    public SnowmanEvent(SnowmanPlugin plugin, DataStore store) {
        this.plugin = plugin;
        this.store = store;
        this.rewards = new Rewards(() -> config);
        this.leaderboard = new Leaderboard(plugin);
        this.flights = new DonationFlights(plugin);
        this.fireworkKey = new NamespacedKey(plugin, "celebration");
    }

    // ---------- загрузка и сохранение ----------

    public void load(EventConfig config) {
        this.config = config;
        YamlConfiguration data = store.loadData();
        origin = DataStore.getLocation(data, "site.origin");
        donation = DataStore.getLocation(data, "site.donation");
        driftPoints[0] = DataStore.getLocation(data, "site.drift-1");
        driftPoints[1] = DataStore.getLocation(data, "site.drift-2");
        leaderboardPoint = DataStore.getPreciseLocation(data, "site.leaderboard");
        try {
            state = State.valueOf(data.getString("state", "IDLE"));
        } catch (IllegalArgumentException e) {
            state = State.IDLE;
        }
        level = Math.max(0, Math.min(data.getInt("level", 0), config.levels().size() - 1));
        buildAt = data.getLong("build-at", 0);
        collectedAt = data.getLong("collected-at", 0);
        buildForced = data.getBoolean("build-forced", false);
        // Старые файлы хранили целые очки; теперь — сотые. Без пересчёта старый вклад стал бы в 100 раз меньше
        long scale = data.getInt("points-scale", 1) == Points.SCALE ? 1 : Points.SCALE;
        ConfigurationSection players = data.getConfigurationSection("players");
        if (players != null) {
            for (String key : players.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(key);
                    contributions.put(new Contributions.Entry(id, players.getString(key + ".name", "?"),
                            players.getLong(key + ".items"), players.getLong(key + ".points") * scale));
                } catch (IllegalArgumentException ignored) {
                    plugin.getLogger().warning("data.yml: пропущен игрок с неверным UUID " + key);
                }
            }
        }
        rewards.load(data.getConfigurationSection("pending-rewards"));
        progress = newProgress(level);
        ConfigurationSection donated = data.getConfigurationSection("donated");
        if (donated != null) {
            for (String key : donated.getKeys(false)) {
                Material material = Material.matchMaterial(key);
                if (material != null) {
                    progress.restore(material, donated.getInt(key));
                }
            }
        }
        Map<ImmutableVector3i, String> savedDrift = new LinkedHashMap<>();
        ConfigurationSection driftSection = data.getConfigurationSection("drift");
        if (driftSection != null) {
            for (String key : driftSection.getKeys(false)) {
                ImmutableVector3i position = DataStore.parsePosition(key);
                if (position != null) {
                    savedDrift.put(position, driftSection.getString(key, "minecraft:air"));
                }
            }
        }
        loadSite();
        if (drift != null) {
            drift.restoreOwned(savedDrift);
        } else {
            orphanDrift = savedDrift;
        }
        if (site == null) {
            return;
        }
        if (state == State.BUILDING) {
            // Сервер выключился посреди постройки: блоки уровня ставим сразу, ивент продолжится со следующего
            site.level(level).forEach(site::place);
            if (drift != null) {
                drift.fill(0);
            }
            Bukkit.getScheduler().runTask(plugin, this::onLevelBuilt);
        } else if (state == State.COLLECTING) {
            drift.fillFraction(progress.fraction());
            Bukkit.getScheduler().runTask(plugin, this::afterProgress);
        } else if (state == State.WAITING) {
            drift.fillFraction(1);
            // Время постройки прошло, пока сервер был выключен: строим сразу, но с таймером — пусть игроки успеют подойти
            buildAt = Math.max(buildAt, System.currentTimeMillis() + countdownMillis());
        }
        updateBar();
    }

    private long countdownMillis() {
        return config.schedule().countdownSeconds() * 1000L;
    }

    /**
     * /snowman reload. Посреди постройки уровня схему менять нельзя — летящие блоки ссылаются на старую.
     */
    public boolean reload(EventConfig newConfig) {
        if (state == State.BUILDING) {
            return false;
        }
        Map<Material, Integer> donatedBefore = progress == null ? Map.of() : new LinkedHashMap<>(progress.donatedView());
        if (state != State.IDLE && (!newConfig.schematic().equals(config.schematic()) || newConfig.rotation() != config.rotation())) {
            plugin.getLogger().warning("Схематика или поворот изменены посреди ивента: уже построенные этапы остались от старой постройки. "
                    + "Чтобы начать с новой, сделайте /snowman reset confirm и /snowman start.");
        }
        clearFlights();
        if (drift != null) {
            drift.clear();
        }
        this.config = newConfig;
        level = Math.min(level, newConfig.levels().size() - 1);
        progress = newProgress(level);
        donatedBefore.forEach(progress::restore);
        loadSite();
        if (state == State.COLLECTING && drift != null) {
            drift.fillFraction(progress.fraction());
            afterProgress();
        } else if (state == State.WAITING) {
            if (drift != null) {
                drift.fillFraction(1);
            }
            if (!newConfig.schedule().enabled()) {
                // Расписание выключили — ждать больше нечего, строим после таймера
                buildAt = Math.min(buildAt, System.currentTimeMillis() + countdownMillis());
            } else if (!buildForced && collectedAt > 0) {
                // Поменяли задержку или время — пересчитываем от момента сбора, а не оставляем старое назначение.
                // Если новое время уже прошло, строим после таймера
                buildAt = Math.max(newConfig.schedule().buildAt(Instant.ofEpochMilli(collectedAt)).toEpochMilli(),
                        System.currentTimeMillis() + countdownMillis());
            }
        }
        updateBar();
        markDirty();
        return true;
    }

    private void loadSite() {
        site = null;
        drift = null;
        siteError = null;
        if (origin == null) {
            return;
        }
        try {
            site = Site.load(plugin, config, origin);
            drift = newDrift();
            if (site.levelCount() != config.levels().size()) {
                plugin.getLogger().warning("Число уровней постройки не совпадает с конфигом");
            }
            for (int i = 0; i < site.levelCount(); i++) {
                if (site.level(i).isEmpty()) {
                    plugin.getLogger().warning("Уровень " + (i + 1) + " не содержит ни одного блока — проверьте height-percent");
                }
            }
        } catch (Site.SiteException e) {
            siteError = e;
            plugin.getLogger().warning("Постройка не загружена: " + Messages.raw(e.messageKey()));
        }
    }

    public void markDirty() {
        dirty = true;
    }

    public void saveIfDirty() {
        if (dirty) {
            save(true);
        }
    }

    public void save(boolean async) {
        dirty = false;
        YamlConfiguration data = new YamlConfiguration();
        DataStore.setLocation(data, "site.origin", origin);
        DataStore.setLocation(data, "site.donation", donation);
        DataStore.setLocation(data, "site.drift-1", driftPoints[0]);
        DataStore.setLocation(data, "site.drift-2", driftPoints[1]);
        DataStore.setPreciseLocation(data, "site.leaderboard", leaderboardPoint);
        data.set("state", state.name());
        data.set("level", level);
        data.set("points-scale", Points.SCALE);
        if (state == State.WAITING) {
            data.set("build-at", buildAt);
            data.set("collected-at", collectedAt);
            data.set("build-forced", buildForced);
        }
        progress.donatedView().forEach((material, amount) -> data.set("donated." + material.getKey().getKey(), amount));
        for (Contributions.Entry entry : contributions.all()) {
            String path = "players." + entry.id();
            data.set(path + ".name", entry.name());
            data.set(path + ".items", entry.items());
            data.set(path + ".points", entry.points());
        }
        rewards.save(data.createSection("pending-rewards"));
        if (drift != null) {
            drift.owned().forEach((position, original) -> data.set("drift." + DataStore.formatPosition(position), original.getAsString()));
        } else {
            orphanDrift.forEach((position, original) -> data.set("drift." + DataStore.formatPosition(position), original));
        }
        store.saveData(data, async);
    }

    public void shutdown() {
        clearFlights();
        if (build != null) {
            build.shutdown();
            build = null;
        }
        save(false);
        hideBar();
        leaderboard.remove();
    }

    // ---------- команды администратора ----------

    public void setOrigin(CommandSender sender, Location location) {
        if (state != State.IDLE) {
            Messages.send(sender, "admin-only-idle");
            return;
        }
        origin = location.toBlockLocation();
        loadSite();
        markDirty();
        if (site == null) {
            sendSiteError(sender);
            return;
        }
        Messages.send(sender, "admin-origin-set", "blocks", site.blocks().size(), "height", site.maxY() - site.minY() + 1);
    }

    /**
     * @param index    0 или 1 — какой сугроб; -1 — оба
     * @param location центр основания сугроба (блок, на котором он начнёт расти), null — вернуть автоматическое место
     */
    public void setDriftPoint(CommandSender sender, int index, Location location) {
        if (state == State.BUILDING) {
            // Из сугробов сейчас вылетают блоки — переставлять их посреди полёта нельзя
            Messages.send(sender, "admin-drift-building");
            return;
        }
        if (location != null && site != null && location.getWorld() != site.world()) {
            Messages.send(sender, "admin-drift-world");
            return;
        }
        Location point = location == null ? null : location.toBlockLocation();
        if (index < 0) {
            driftPoints[0] = point;
            driftPoints[1] = point;
        } else {
            driftPoints[index] = point;
        }
        if (drift != null) {
            drift.clear();
        }
        clearFlights();
        drift = site == null ? null : newDrift();
        if ((state == State.COLLECTING || state == State.WAITING) && drift != null) {
            drift.fillFraction(progress.fraction());
        }
        markDirty();
        if (location == null) {
            Messages.send(sender, "admin-drift-auto");
        } else {
            Messages.send(sender, "admin-drift-set", "number", index + 1, "x", point.getBlockX(), "y", point.getBlockY(), "z", point.getBlockZ());
        }
    }

    private DriftManager newDrift() {
        return new DriftManager(site, config.drift(), driftPoint(0), driftPoint(1));
    }

    private ImmutableVector3i driftPoint(int index) {
        Location point = driftPoints[index];
        if (point == null || point.getWorld() != site.world()) {
            return null;
        }
        return new ImmutableVector3i(point.getBlockX(), point.getBlockY(), point.getBlockZ());
    }

    public DriftManager drift() {
        return drift;
    }

    public void setDonation(CommandSender sender, Block block) {
        donation = block.getLocation();
        markDirty();
        Messages.send(sender, "admin-donation-set", "block", block.getType().getKey().getKey());
    }

    public void start(CommandSender sender) {
        if (state != State.IDLE) {
            Messages.send(sender, state == State.FINISHED ? "admin-finished-reset-first" : "admin-already-running");
            return;
        }
        if (origin == null) {
            Messages.send(sender, "admin-no-origin");
            return;
        }
        if (site == null) {
            sendSiteError(sender);
            return;
        }
        if (donation == null) {
            Messages.send(sender, "admin-no-donation");
            return;
        }
        Map<ImmutableVector3i, String> backup = new LinkedHashMap<>();
        for (ImmutableVector3i position : site.blocks().keySet()) {
            backup.put(position, site.world().getBlockAt(position.x(), position.y(), position.z()).getBlockData().getAsString());
        }
        store.saveBackup(backup);
        contributions.clear();
        level = 0;
        progress = newProgress(0);
        state = State.COLLECTING;
        drift.fill(0);
        Messages.broadcast("event-started", "level", levelName(), "x", donation.getBlockX(), "y", donation.getBlockY(), "z", donation.getBlockZ());
        afterProgress();
        save(true);
    }

    public void skip(CommandSender sender) {
        switch (state) {
            case COLLECTING -> {
                progress.fillAll();
                Messages.send(sender, "admin-skipped");
                afterProgress();
            }
            case WAITING -> {
                // Не ждать назначенного времени: сразу таймер и постройка
                buildAt = System.currentTimeMillis() + countdownMillis();
                buildForced = true;
                Messages.send(sender, "admin-skipped-waiting", "seconds", config.schedule().countdownSeconds());
                updateBar();
                markDirty();
            }
            case BUILDING -> {
                Messages.send(sender, "admin-skipped");
                build.finishNow();
            }
            default -> Messages.send(sender, "admin-not-running");
        }
    }

    /**
     * Закрыть завершённый ивент, оставив снеговика в мире: в отличие от reset, ничего не сносится.
     * После этого снеговик — обычные блоки (защита снимается), а место можно занять новым ивентом.
     */
    public void keep(CommandSender sender) {
        if (state != State.FINISHED) {
            Messages.send(sender, "admin-keep-not-finished");
            return;
        }
        clearFlights();
        if (drift != null) {
            drift.clear();
        }
        // Бэкап хранил землю до постройки; раз снеговик остаётся, возвращать её больше некуда
        store.deleteBackup();
        contributions.clear();
        state = State.IDLE;
        level = 0;
        progress = newProgress(0);
        hideBar();
        updateLeaderboard();
        save(true);
        Messages.send(sender, "admin-kept");
    }

    public void reset(CommandSender sender) {
        clearFlights();
        if (build != null) {
            build.abort();
            build = null;
        }
        Map<ImmutableVector3i, String> backup = store.loadBackup();
        World world = site != null ? site.world() : origin == null ? null : origin.getWorld();
        if (world != null) {
            // Возвращаем всё из бэкапа, а не только клетки текущей схематики: если схематику сменили
            // посреди ивента, блоки старой постройки иначе остались бы стоять
            Map<ImmutableVector3i, String> restore = new LinkedHashMap<>(backup);
            // Клетки постройки без записи в бэкапе чистим только во время ивента — до старта там ничего
            // нашего нет, а после keep там стоит оставленный снеговик
            if (state != State.IDLE && site != null) {
                site.blocks().keySet().forEach(position -> restore.putIfAbsent(position, "minecraft:air"));
            }
            restore.forEach((position, original) -> {
                Block block = world.getBlockAt(position.x(), position.y(), position.z());
                try {
                    block.setBlockData(Bukkit.createBlockData(original), false);
                } catch (IllegalArgumentException e) {
                    block.setType(Material.AIR, false);
                }
            });
        }
        if (drift != null) {
            drift.clear();
        }
        store.deleteBackup();
        contributions.clear();
        state = State.IDLE;
        level = 0;
        progress = newProgress(0);
        hideBar();
        save(true);
        Messages.send(sender, "admin-reset");
    }

    // ---------- сдача ресурсов ----------

    /**
     * @param limit сколько максимум сдать за раз (стак или «всё»)
     */
    public void donate(Player player, Material material, int limit) {
        if (state != State.COLLECTING) {
            sendClosed(player);
            return;
        }
        int remaining = progress.remaining(material);
        if (remaining <= 0) {
            Messages.send(player, "donate-resource-done");
            return;
        }
        Material current = progress.current();
        if (config.sequentialResources() && material != current) {
            // Меню прячет следующие ресурсы, но клик мог прийти из устаревшего окна
            Messages.send(player, "donate-locked");
            return;
        }
        int amount = Math.min(Math.min(remaining, limit), count(player.getInventory(), material));
        if (amount <= 0) {
            Messages.send(player, "donate-nothing", "item", Component.translatable(material.translationKey()));
            return;
        }
        remove(player.getInventory(), material, amount);
        double before = progress.fraction();
        progress.add(material, amount);
        long points = amount * config.pointsFor(material);
        contributions.add(player.getUniqueId(), player.getName(), amount, points);
        Messages.send(player, "donated", "amount", amount, "item", Component.translatable(material.translationKey()), "points", Points.format(points));
        player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 0.6F, 1.2F);
        launchFlight(material, amount, before, progress.fraction());
        markDirty();
        Material next = progress.current();
        if (config.sequentialResources() && next != null && next != current) {
            Component item = Component.translatable(next.translationKey());
            for (Player viewer : titleViewers()) {
                Messages.send(viewer, "resource-unlocked", "item", item, "required", progress.required().get(next));
                viewer.showTitle(Title.title(Component.empty(), Messages.get("subtitle-resource-unlocked", "item", item),
                        Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(2), Duration.ofMillis(500))));
                viewer.playSound(viewer.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 0.7F, 1.2F);
            }
        }
        afterProgress();
    }

    public void sendClosed(Player player) {
        switch (state) {
            case BUILDING -> Messages.send(player, "donate-building");
            case WAITING -> Messages.send(player, "donate-waiting", "time", buildTime(), "date", buildDate());
            default -> Messages.send(player, "donate-closed");
        }
    }

    /**
     * Сданное летит от точки сдачи в сугроб; сугроб дорастёт, когда долетит последний блок.
     */
    private void launchFlight(Material material, int amount, double before, double after) {
        EventConfig.Flight settings = config.flight();
        if (!settings.enabled() || drift == null || donation == null || donation.getWorld() != site.world()) {
            return;
        }
        int count = (int) Math.max(1, Math.min(settings.maxBlocks(), Math.round(Math.sqrt(amount))));
        Location from = donation.clone().add(0.5, 1.3, 0.5);
        DriftManager target = drift;
        flightsInAir++;
        flights.launch(from, material, count, () -> {
            ImmutableVector3i spot = target.landingSpot(before, after);
            return new Location(site.world(), spot.x() + 0.5, spot.y() + 0.5, spot.z() + 0.5);
        }, settings, () -> {
            flightsInAir = Math.max(0, flightsInAir - 1);
            if (flightsInAir == 0 && drift == target && (state == State.COLLECTING || state == State.WAITING)) {
                drift.fillFraction(progress.fraction());
            }
        });
    }

    private void clearFlights() {
        flights.clear();
        flightsInAir = 0;
    }

    /**
     * Обычный предмет без названия и чар: иначе можно было бы «сдать» переименованный или кастомный предмет на той же основе.
     */
    public static boolean isPlain(ItemStack item, Material material) {
        return item != null && item.getType() == material && !item.hasItemMeta();
    }

    public static int count(PlayerInventory inventory, Material material) {
        int total = 0;
        for (ItemStack item : inventory.getStorageContents()) {
            if (isPlain(item, material)) {
                total += item.getAmount();
            }
        }
        return total;
    }

    private static void remove(PlayerInventory inventory, Material material, int amount) {
        ItemStack[] contents = inventory.getStorageContents();
        for (int slot = 0; slot < contents.length && amount > 0; slot++) {
            ItemStack item = contents[slot];
            if (!isPlain(item, material)) {
                continue;
            }
            int take = Math.min(amount, item.getAmount());
            amount -= take;
            item.setAmount(item.getAmount() - take);
            contents[slot] = item.getAmount() <= 0 ? null : item;
        }
        inventory.setStorageContents(contents);
    }

    private void afterProgress() {
        if (state != State.COLLECTING) {
            return;
        }
        if (drift != null && flightsInAir == 0) {
            drift.fillFraction(progress.fraction());
        }
        updateBar();
        DonateMenu.refreshAll(this);
        if (progress.isComplete()) {
            completeLevel();
        }
    }

    // ---------- уровни ----------

    private void completeLevel() {
        if (!config.schedule().enabled()) {
            startBuild();
            return;
        }
        EventConfig.Schedule schedule = config.schedule();
        state = State.WAITING;
        Instant now = Instant.now();
        collectedAt = now.toEpochMilli();
        buildForced = false;
        buildAt = schedule.buildAt(now).toEpochMilli();
        Messages.broadcast("level-collected", "level", levelName(), "number", level + 1, "time", buildTime(), "date", buildDate(),
                "collected", TIME.format(Instant.ofEpochMilli(collectedAt).atZone(schedule.zone())), "left", timeLeft());
        for (Player player : titleViewers()) {
            player.showTitle(Title.title(Messages.get("title-level-collected", "level", levelName()),
                    Messages.get("subtitle-level-collected", "time", buildTime(), "date", buildDate()),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(4), Duration.ofMillis(700))));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8F, 1.1F);
        }
        DonateMenu.closeAll();
        updateBar();
        save(true);
    }

    /**
     * Назначенное время пришло (или расписание выключено): сугробы взлетают и строят этап.
     */
    private void startBuild() {
        boolean scheduled = state == State.WAITING;
        state = State.BUILDING;
        if (drift != null) {
            // Последние сданные ресурсы могли ещё не долететь — сугроб к постройке должен быть полным
            drift.fillFraction(1);
        }
        Messages.broadcast(scheduled ? "build-started" : "level-complete", "level", levelName(), "number", level + 1);
        for (Player player : titleViewers()) {
            player.showTitle(Title.title(Messages.get("title-level-complete", "level", levelName()),
                    Messages.get("subtitle-level-complete"), Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(700))));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8F, 1.1F);
        }
        DonateMenu.closeAll();
        updateBar();
        build = new LevelBuild(plugin, site, site.level(level), config.animation(), drift, this::onLevelBuilt);
        build.start();
        save(true);
    }

    private void onLevelBuilt() {
        build = null;
        if (state != State.BUILDING) {
            return;
        }
        if (level + 1 < config.levels().size()) {
            level++;
            progress = newProgress(level);
            state = State.COLLECTING;
            if (drift != null) {
                drift.fill(0);
            }
            Messages.broadcast("level-started", "level", levelName(), "number", level + 1, "total", config.levels().size());
            afterProgress();
        } else {
            finish();
        }
        save(true);
    }

    private void finish() {
        state = State.FINISHED;
        updateBar();
        celebrate();
        List<Contributions.Entry> ranking = contributions.ranking();
        Set<UUID> leaders = new HashSet<>();
        contributions.leaders().forEach(entry -> leaders.add(entry.id()));
        for (Contributions.Entry entry : ranking) {
            rewards.grant(entry.id(), leaders.contains(entry.id()) ? List.of(Rewards.TOP, Rewards.COMPLETION) : List.of(Rewards.COMPLETION));
        }
        if (config.rewardNearbySpectators()) {
            for (Player player : nearbyPlayers()) {
                if (contributions.place(player.getUniqueId()) == 0) {
                    rewards.grant(player.getUniqueId(), List.of(Rewards.COMPLETION));
                }
            }
        }
        if (ranking.isEmpty()) {
            Messages.broadcast("finish-nobody");
            return;
        }
        Messages.broadcast("finish-header");
        for (int i = 0; i < Math.min(5, ranking.size()); i++) {
            Contributions.Entry entry = ranking.get(i);
            Messages.broadcast("finish-line", "place", i + 1, "player", entry.name(), "points", Points.format(entry.points()), "items", entry.items());
        }
        if (!leaders.isEmpty()) {
            Messages.broadcast("finish-leader", "players", String.join(", ", contributions.leaders().stream().map(Contributions.Entry::name).toList()));
        }
    }

    private void celebrate() {
        if (site == null) {
            return;
        }
        EventConfig.Celebration settings = config.celebration();
        Site celebrated = site;
        int[] wave = {0};
        Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            // Ивент сбросили посреди салюта — дальше не стреляем
            if (wave[0]++ >= settings.waves() || site != celebrated || state != State.FINISHED) {
                task.cancel();
                return;
            }
            // Каждая волна гуще предыдущей: салют разгорается к финальному залпу
            int count = settings.firstWave() + (wave[0] - 1) * settings.waveGrowth();
            for (int i = 0; i < count; i++) {
                launchFirework(celebrated, settings.spread());
            }
        }, 0, settings.waveIntervalTicks());
        for (Player player : titleViewers()) {
            player.showTitle(Title.title(Messages.get("title-finish"), Messages.get("subtitle-finish")));
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1F, 1F);
        }
    }

    private static final Color[] FIREWORK_COLORS = {
            Color.WHITE, Color.AQUA, Color.fromRGB(0x6fa8dc), Color.fromRGB(0xbfe9ff), Color.fromRGB(0x9fc5e8), Color.fromRGB(0xffd966)
    };
    private static final FireworkEffect.Type[] FIREWORK_TYPES = {
            FireworkEffect.Type.BALL, FireworkEffect.Type.BALL_LARGE, FireworkEffect.Type.STAR, FireworkEffect.Type.BURST
    };

    /**
     * Ракета стартует вокруг верхушки постройки и летит с наклоном наружу; скорость и сила разные —
     * взрывы ложатся веером на разной высоте, а не столбом в одной точке.
     */
    private void launchFirework(Site at, double spread) {
        ThreadLocalRandom random = ThreadLocalRandom.current();
        Location top = at.top();
        double angle = random.nextDouble(Math.PI * 2);
        double distance = random.nextDouble(spread * 0.3, spread);
        Location start = top.clone().add(Math.cos(angle) * distance * 0.35, random.nextDouble(0, 5), Math.sin(angle) * distance * 0.35);
        // Наклон наружу: дальние ракеты сильнее отклоняются в сторону
        // Боковая скорость растёт с разлётом: за ~30 тиков полёта дальняя ракета уходит ещё на полразлёта наружу
        double sideways = distance * random.nextDouble(0.012, 0.025);
        org.bukkit.util.Vector velocity = new org.bukkit.util.Vector(Math.cos(angle) * sideways, random.nextDouble(0.4, 0.85), Math.sin(angle) * sideways);
        at.world().spawn(start, Firework.class, firework -> {
            FireworkMeta meta = firework.getFireworkMeta();
            Color main = FIREWORK_COLORS[random.nextInt(FIREWORK_COLORS.length)];
            Color second = FIREWORK_COLORS[random.nextInt(FIREWORK_COLORS.length)];
            meta.addEffect(FireworkEffect.builder().with(FIREWORK_TYPES[random.nextInt(FIREWORK_TYPES.length)])
                    .withColor(main, second).withFade(Color.WHITE).flicker(random.nextBoolean()).trail(random.nextBoolean()).build());
            meta.setPower(random.nextInt(1, 3));
            firework.setFireworkMeta(meta);
            // Под углом ракета летит по заданной скорости, а не только вверх
            firework.setShotAtAngle(true);
            firework.setVelocity(velocity);
            // Помечаем, чтобы праздничный салют никого не ранил
            firework.getPersistentDataContainer().set(fireworkKey, PersistentDataType.BYTE, (byte) 1);
        });
    }

    // ---------- полоса прогресса ----------

    private void updateBar() {
        switch (state) {
            case COLLECTING -> {
                Material current = progress.current();
                if (config.sequentialResources() && current != null) {
                    // Поочерёдно: в полосе — что нужно прямо сейчас и сколько осталось
                    bar.name(Messages.get("bossbar-collecting-resource", "level", levelName(), "number", level + 1,
                            "total", config.levels().size(), "percent", (int) Math.floor(progress.fraction() * 100),
                            "item", Component.translatable(current.translationKey()),
                            "donated", progress.donated(current), "required", progress.required().get(current)));
                } else {
                    bar.name(Messages.get("bossbar-collecting", "level", levelName(), "number", level + 1,
                            "total", config.levels().size(), "percent", (int) Math.floor(progress.fraction() * 100)));
                }
                bar.progress((float) Math.max(0, Math.min(1, progress.fraction())));
                bar.color(BossBar.Color.BLUE);
            }
            case WAITING -> {
                long left = buildAt - System.currentTimeMillis();
                long countdown = countdownMillis();
                if (countdown > 0 && left <= countdown) {
                    bar.name(Messages.get("bossbar-countdown", "level", levelName(), "number", level + 1,
                            "total", config.levels().size(), "seconds", secondsLeft()));
                    bar.progress((float) Math.max(0, Math.min(1, (double) left / countdown)));
                    bar.color(BossBar.Color.RED);
                } else {
                    bar.name(Messages.get("bossbar-waiting", "level", levelName(), "number", level + 1,
                            "total", config.levels().size(), "time", buildTime(), "date", buildDate(), "left", timeLeft()));
                    bar.progress(1);
                    bar.color(BossBar.Color.YELLOW);
                }
            }
            case BUILDING -> {
                bar.name(Messages.get("bossbar-building", "level", levelName(), "number", level + 1, "total", config.levels().size()));
                bar.progress(1);
                bar.color(BossBar.Color.WHITE);
            }
            case FINISHED -> {
                bar.name(Messages.get("bossbar-finished"));
                bar.progress(1);
                bar.color(BossBar.Color.GREEN);
            }
            default -> hideBar();
        }
        updateLeaderboard();
    }

    private void updateLeaderboard() {
        Location at = leaderboardLocation();
        if (state == State.IDLE || at == null) {
            leaderboard.remove();
            return;
        }
        Component header = switch (state) {
            case COLLECTING -> Messages.get("leaderboard-header-collecting", "level", levelName(), "number", level + 1,
                    "total", config.levels().size(), "percent", (int) Math.floor(progress.fraction() * 100));
            case WAITING -> Messages.get("leaderboard-header-waiting", "level", levelName(), "number", level + 1,
                    "total", config.levels().size(), "time", buildTime(), "date", buildDate());
            case BUILDING -> Messages.get("leaderboard-header-building", "level", levelName(), "number", level + 1, "total", config.levels().size());
            default -> Messages.get("leaderboard-header-finished");
        };
        leaderboard.update(at, config.leaderboard(), contributions, header);
    }

    /**
     * Заданное админом место, иначе — над точкой сдачи, чтобы таблица была видна оттуда, где сдают.
     */
    private Location leaderboardLocation() {
        if (leaderboardPoint != null) {
            return leaderboardPoint.clone();
        }
        if (donation == null) {
            return null;
        }
        Location above = donation.clone().add(0.5, 2.2, 0.5);
        // Лицом от постройки наружу — к тем, кто подходит к точке сдачи
        above.setYaw(0);
        above.setPitch(0);
        if (site != null) {
            org.bukkit.util.Vector outward = above.toVector().subtract(site.center().toVector()).setY(0);
            if (outward.lengthSquared() > 0.01) {
                above.setDirection(outward);
                above.setPitch(0);
            }
        }
        return above;
    }

    public void setLeaderboard(CommandSender sender, Location location) {
        leaderboardPoint = location == null ? null : location.clone();
        markDirty();
        updateLeaderboard();
        Messages.send(sender, location == null ? "admin-leaderboard-auto" : "admin-leaderboard-set");
    }

    /**
     * Раз в секунду: показать полосу тем, кто подошёл, и убрать у ушедших; обновить голограмму.
     */
    public void tickBar() {
        if (state == State.WAITING && site != null) {
            tickWaiting();
            if (state != State.WAITING) {
                // Постройка уже началась и сама обновила полосу и таблицу
                return;
            }
        }
        updateLeaderboard();
        if (state == State.IDLE || site == null) {
            return;
        }
        Set<UUID> nearby = new HashSet<>();
        for (Player player : playersWithin(config.bossbarRadius())) {
            nearby.add(player.getUniqueId());
            if (barViewers.add(player.getUniqueId())) {
                player.showBossBar(bar);
            }
        }
        for (UUID id : new ArrayList<>(barViewers)) {
            if (!nearby.contains(id)) {
                barViewers.remove(id);
                Player player = Bukkit.getPlayer(id);
                if (player != null) {
                    player.hideBossBar(bar);
                }
            }
        }
    }

    /**
     * Раз в секунду в ожидании: время в полосе идёт, в последние секунды — обратный отсчёт в титрах, в ноль — постройка.
     */
    private void tickWaiting() {
        long left = buildAt - System.currentTimeMillis();
        if (left <= 0) {
            startBuild();
            return;
        }
        updateBar();
        if (left <= countdownMillis()) {
            long seconds = secondsLeft();
            for (Player player : titleViewers()) {
                // Без затухания: цифры сменяют друг друга каждую секунду
                player.showTitle(Title.title(Messages.get("title-countdown", "seconds", seconds),
                        Messages.get("subtitle-countdown", "level", levelName()),
                        Title.Times.times(Duration.ZERO, Duration.ofMillis(1100), Duration.ZERO)));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.8F, seconds <= 3 ? 1.6F : 1.2F);
            }
        }
    }

    private long secondsLeft() {
        return Math.max(1, (buildAt - System.currentTimeMillis() + 999) / 1000);
    }

    private ZonedDateTime buildMoment() {
        return Instant.ofEpochMilli(buildAt).atZone(config.schedule().zone());
    }

    public String buildTime() {
        return TIME.format(buildMoment());
    }

    public String buildDate() {
        return DATE.format(buildMoment());
    }

    /**
     * «5 ч 12 мин» / «12 мин» / «40 сек» — сколько ждать постройки.
     */
    private Component timeLeft() {
        long seconds = Math.max(0, (buildAt - System.currentTimeMillis() + 999) / 1000);
        if (seconds < 60) {
            return Messages.get("time-left-seconds", "seconds", seconds);
        }
        // Минуты вверх: при 2 мин 59 сек «через 2 мин» обещало бы постройку раньше, чем она будет
        long totalMinutes = (seconds + 59) / 60;
        long hours = totalMinutes / 60;
        long minutes = totalMinutes % 60;
        if (hours > 0) {
            return Messages.get("time-left-hours", "hours", hours, "minutes", minutes);
        }
        return Messages.get("time-left-minutes", "minutes", minutes);
    }

    public long buildAt() {
        return buildAt;
    }

    private void hideBar() {
        for (UUID id : barViewers) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                player.hideBossBar(bar);
            }
        }
        barViewers.clear();
    }

    /**
     * После перезахода у игрока новый клиент без полосы: без этого он числился бы зрителем и полосу больше не увидел.
     */
    public void forgetBarViewer(UUID id) {
        barViewers.remove(id);
        leaderboard.forget(id);
    }

    // ---------- общее ----------

    public List<Player> nearbyPlayers() {
        return playersWithin(config.nearbyRadius());
    }

    /**
     * Титры и звуки этапов — тем, кто видит полосу прогресса: в одном радиусе, чтобы не было титров без полосы и наоборот.
     */
    private List<Player> titleViewers() {
        return playersWithin(config.bossbarRadius());
    }

    private List<Player> playersWithin(double radius) {
        if (site == null) {
            return List.of();
        }
        Location center = site.center();
        return site.world().getPlayers().stream().filter(player -> player.getLocation().distanceSquared(center) <= radius * radius).toList();
    }

    public boolean isNearDonation(Player player) {
        return donation != null && donation.getWorld() == player.getWorld()
                && player.getLocation().distanceSquared(donation.clone().add(0.5, 0.5, 0.5)) <= config.donationRadius() * config.donationRadius();
    }

    public boolean isDonationBlock(Block block) {
        return donation != null && donation.getWorld() == block.getWorld()
                && donation.getBlockX() == block.getX() && donation.getBlockY() == block.getY() && donation.getBlockZ() == block.getZ();
    }

    /**
     * Блоки сугробов и места постройки во время ивента не ломаются и не заменяются: снег из сугроба
     * иначе можно было бы сдать повторно, а постройку — разобрать.
     */
    public boolean isProtected(Block block) {
        ImmutableVector3i position = new ImmutableVector3i(block.getX(), block.getY(), block.getZ());
        if (drift != null && block.getWorld() == site.world() && drift.owned().containsKey(position)) {
            return true;
        }
        return state != State.IDLE && site != null && block.getWorld() == site.world() && site.blocks().containsKey(position);
    }

    public boolean isCelebrationFirework(Firework firework) {
        return firework.getPersistentDataContainer().has(fireworkKey, PersistentDataType.BYTE);
    }

    private void sendSiteError(CommandSender sender) {
        if (siteError != null) {
            Messages.send(sender, siteError.messageKey(), siteError.placeholders());
        } else {
            Messages.send(sender, "admin-no-origin");
        }
    }

    private LevelProgress<Material> newProgress(int index) {
        return new LevelProgress<>(config.levels().get(index).resources());
    }

    public void deliverPendingRewards(Player player) {
        if (rewards.deliverPending(player)) {
            markDirty();
        }
    }

    public String levelName() {
        return config.levels().get(level).name();
    }

    public State state() {
        return state;
    }

    public int level() {
        return level;
    }

    public EventConfig config() {
        return config;
    }

    public LevelProgress<Material> progress() {
        return progress;
    }

    public Contributions contributions() {
        return contributions;
    }

    public Location origin() {
        return origin;
    }

    public Location donation() {
        return donation;
    }

    public Site site() {
        return site;
    }
}
