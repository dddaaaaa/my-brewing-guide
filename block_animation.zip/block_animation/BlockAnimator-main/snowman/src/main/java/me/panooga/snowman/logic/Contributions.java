package me.panooga.snowman.logic;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Вклады игроков за весь ивент. Ранжирование — по очкам; при равенстве выше тот, кто сдал больше предметов.
 */
public final class Contributions {

    private static final Comparator<Entry> RANKING = Comparator.comparingLong(Entry::points).reversed()
            .thenComparing(Comparator.comparingLong(Entry::items).reversed())
            .thenComparing(Entry::name, String.CASE_INSENSITIVE_ORDER);

    private final Map<UUID, Entry> entries = new LinkedHashMap<>();

    public void add(UUID id, String name, long items, long points) {
        Entry old = entries.get(id);
        long oldItems = old == null ? 0 : old.items();
        long oldPoints = old == null ? 0 : old.points();
        entries.put(id, new Entry(id, name, oldItems + items, oldPoints + points));
    }

    public void put(Entry entry) {
        entries.put(entry.id(), entry);
    }

    public Optional<Entry> get(UUID id) {
        return Optional.ofNullable(entries.get(id));
    }

    public Collection<Entry> all() {
        return entries.values();
    }

    public List<Entry> ranking() {
        List<Entry> output = new ArrayList<>(entries.values());
        output.removeIf(entry -> entry.points() <= 0);
        output.sort(RANKING);
        return output;
    }

    /**
     * Все, у кого максимум очков: памятная награда делится поровну, а не достаётся тому, кто случайно оказался первым в списке.
     */
    public List<Entry> leaders() {
        List<Entry> ranking = ranking();
        if (ranking.isEmpty()) {
            return List.of();
        }
        long best = ranking.get(0).points();
        return ranking.stream().filter(entry -> entry.points() == best).toList();
    }

    /**
     * @return место в таблице с 1, или 0, если игрок ничего не сдал
     */
    public int place(UUID id) {
        List<Entry> ranking = ranking();
        for (int i = 0; i < ranking.size(); i++) {
            if (ranking.get(i).id().equals(id)) {
                return i + 1;
            }
        }
        return 0;
    }

    public void clear() {
        entries.clear();
    }

    public record Entry(UUID id, String name, long items, long points) {
    }
}
