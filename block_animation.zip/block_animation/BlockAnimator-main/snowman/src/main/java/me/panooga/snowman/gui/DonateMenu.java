package me.panooga.snowman.gui;

import me.panooga.snowman.SnowmanPlugin;
import me.panooga.snowman.config.Messages;
import me.panooga.snowman.event.SnowmanEvent;
import me.panooga.snowman.logic.Contributions;
import me.panooga.snowman.logic.Points;
import me.panooga.snowman.logic.LevelProgress;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Меню сдачи: ресурсы текущего уровня с прогрессом. ЛКМ — сдать всё, что есть, ПКМ — один стак.
 * Открытые меню всех игроков обновляются после каждой сдачи, чтобы прогресс был виден вживую.
 */
public final class DonateMenu implements InventoryHolder {

    private static final int[] RESOURCE_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
    private static final int INFO_SLOT = 4;
    private static final int SELF_SLOT = 48;
    private static final int CLOSE_SLOT = 49;
    private static final int TOP_SLOT = 50;
    private static final int BAR_LENGTH = 20;

    private final SnowmanEvent event;
    private final Player player;
    private final Inventory inventory;
    private final Map<Integer, Material> resourceSlots = new HashMap<>();

    private DonateMenu(SnowmanEvent event, Player player) {
        this.event = event;
        this.player = player;
        this.inventory = Bukkit.createInventory(this, 54, Messages.get("menu-title", "level", event.levelName()));
        render();
    }

    public static void open(SnowmanEvent event, Player player) {
        switch (event.state()) {
            case COLLECTING -> player.openInventory(new DonateMenu(event, player).inventory);
            default -> event.sendClosed(player);
        }
    }

    public static void refreshAll(SnowmanEvent event) {
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.getOpenInventory().getTopInventory().getHolder() instanceof DonateMenu menu) {
                menu.render();
            }
        }
    }

    /**
     * Закрытие переносится на следующий тик: закрывать инвентарь прямо из обработчика клика нельзя.
     */
    public static void closeAll() {
        Bukkit.getScheduler().runTask(SnowmanPlugin.getPlugin(SnowmanPlugin.class), () -> {
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (online.getOpenInventory().getTopInventory().getHolder() instanceof DonateMenu) {
                    online.closeInventory();
                }
            }
        });
    }

    void click(int slot, ClickType click) {
        if (slot == CLOSE_SLOT) {
            player.closeInventory();
            return;
        }
        Material material = resourceSlots.get(slot);
        if (material != null) {
            event.donate(player, material, click.isRightClick() ? material.getMaxStackSize() : Integer.MAX_VALUE);
        }
    }

    private void render() {
        if (event.state() != SnowmanEvent.State.COLLECTING) {
            return;
        }
        inventory.clear();
        resourceSlots.clear();
        ItemStack filler = item(Material.LIGHT_BLUE_STAINED_GLASS_PANE, Component.empty(), List.of());
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            if (slot < 9 || slot >= 45 || slot % 9 == 0 || slot % 9 == 8) {
                inventory.setItem(slot, filler);
            }
        }
        LevelProgress<Material> progress = event.progress();
        int total = event.config().levels().size();
        int percent = (int) Math.floor(progress.fraction() * 100);
        inventory.setItem(INFO_SLOT, item(Material.CARVED_PUMPKIN, Messages.item("menu-info-name", "level", event.levelName()),
                Messages.lore("menu-info-lore", "number", event.level() + 1, "total", total, "percent", percent, "bar", bar(progress.fraction()))));

        int index = 0;
        Material current = progress.current();
        boolean hidden = false;
        for (Map.Entry<Material, Integer> entry : progress.required().entrySet()) {
            if (index >= RESOURCE_SLOTS.length) {
                break;
            }
            if (hidden) {
                // Следующие ресурсы — загадка: видно только, что они будут, но не что именно и сколько
                inventory.setItem(RESOURCE_SLOTS[index++], item(Material.GRAY_STAINED_GLASS_PANE,
                        Messages.item("menu-locked-name"), Messages.lore("menu-locked")));
                continue;
            }
            Material material = entry.getKey();
            if (event.config().sequentialResources() && material == current) {
                hidden = true;
            }
            int required = entry.getValue();
            int donated = progress.donated(material);
            int have = SnowmanEvent.count(player.getInventory(), material);
            boolean done = donated >= required;
            List<Component> lore = done
                    ? Messages.lore("menu-resource-done", "donated", donated, "required", required)
                    : Messages.lore("menu-resource", "donated", donated, "required", required, "have", have,
                    "points", Points.format(event.config().pointsFor(material)), "bar", bar((double) donated / required));
            ItemStack stack = item(material, null, lore);
            if (done) {
                ItemMeta meta = stack.getItemMeta();
                meta.setEnchantmentGlintOverride(true);
                stack.setItemMeta(meta);
            }
            int slot = RESOURCE_SLOTS[index++];
            inventory.setItem(slot, stack);
            resourceSlots.put(slot, material);
        }

        Contributions contributions = event.contributions();
        Contributions.Entry self = contributions.get(player.getUniqueId()).orElse(null);
        ItemStack head = item(Material.PLAYER_HEAD, Messages.item("menu-self-name"), self == null
                ? Messages.lore("menu-self-empty")
                : Messages.lore("menu-self", "points", Points.format(self.points()), "items", self.items(), "place", contributions.place(player.getUniqueId())));
        if (head.getItemMeta() instanceof SkullMeta skull) {
            skull.setOwningPlayer(player);
            head.setItemMeta(skull);
        }
        inventory.setItem(SELF_SLOT, head);

        List<Component> topLore = new ArrayList<>();
        List<Contributions.Entry> ranking = contributions.ranking();
        for (int i = 0; i < Math.min(5, ranking.size()); i++) {
            Contributions.Entry entry = ranking.get(i);
            topLore.add(Messages.item("menu-top-line", "place", i + 1, "player", entry.name(), "points", Points.format(entry.points())));
        }
        if (topLore.isEmpty()) {
            topLore.addAll(Messages.lore("menu-top-empty"));
        }
        inventory.setItem(TOP_SLOT, item(Material.NETHER_STAR, Messages.item("menu-top-name"), topLore));
        inventory.setItem(CLOSE_SLOT, item(Material.BARRIER, Messages.item("menu-close"), List.of()));
    }

    private static String bar(double fraction) {
        int filled = (int) Math.round(Math.max(0, Math.min(1, fraction)) * BAR_LENGTH);
        return Messages.raw("bar-filled").repeat(filled) + Messages.raw("bar-empty").repeat(BAR_LENGTH - filled);
    }

    private static ItemStack item(Material material, Component name, List<Component> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (name != null) {
            meta.displayName(name);
        }
        meta.lore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        stack.setItemMeta(meta);
        return stack;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}
