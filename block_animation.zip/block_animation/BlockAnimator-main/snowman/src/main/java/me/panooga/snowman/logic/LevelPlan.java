package me.panooga.snowman.logic;

import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Делит постройку по высоте на уровни. Снеговик собирается снизу вверх, поэтому кусок уровня — это
 * горизонтальный пояс слоёв, а не произвольная часть блоков.
 */
public final class LevelPlan {

    private LevelPlan() {
    }

    /**
     * @param heightPercents верхняя граница каждого уровня в процентах высоты, по возрастанию;
     *                       последний уровень всегда забирает всё до верха, даже если указано меньше 100
     */
    public static List<List<ImmutableVector3i>> split(Collection<ImmutableVector3i> positions, List<Integer> heightPercents) {
        if (heightPercents.isEmpty()) {
            throw new IllegalArgumentException("At least one level is required");
        }
        List<List<ImmutableVector3i>> levels = new ArrayList<>();
        heightPercents.forEach(ignored -> levels.add(new ArrayList<>()));
        if (positions.isEmpty()) {
            return levels;
        }
        int minY = Integer.MAX_VALUE;
        int maxY = Integer.MIN_VALUE;
        for (ImmutableVector3i position : positions) {
            minY = Math.min(minY, position.y());
            maxY = Math.max(maxY, position.y());
        }
        int height = maxY - minY + 1;
        int[] bounds = layerBounds(height, heightPercents);
        for (ImmutableVector3i position : positions) {
            int layer = position.y() - minY;
            int level = 0;
            while (level < bounds.length - 1 && layer >= bounds[level]) {
                level++;
            }
            levels.get(level).add(position);
        }
        return levels;
    }

    /**
     * Верхняя граница (не включительно) каждого уровня в слоях от низа постройки.
     */
    static int[] layerBounds(int height, List<Integer> heightPercents) {
        int[] bounds = new int[heightPercents.size()];
        for (int i = 0; i < bounds.length; i++) {
            bounds[i] = (int) Math.round(height * heightPercents.get(i) / 100.0);
        }
        bounds[bounds.length - 1] = height;
        return bounds;
    }
}
