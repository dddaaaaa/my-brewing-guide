package me.panooga.snowman.site;

import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import org.bukkit.Material;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Встроенный снеговик: три кома, шляпа, шарф, лицо и руки. Нужен, чтобы ивент можно было провести и проверить
 * без своей схематики. Начало координат — центр нижнего слоя, лицо смотрит на -Z (север) при повороте 0.
 */
public final class BuiltinSnowman {

    private BuiltinSnowman() {
    }

    public static Map<ImmutableVector3i, Material> generate(int rotation) {
        Map<ImmutableVector3i, Material> blocks = new LinkedHashMap<>();
        sphere(blocks, 4.5, 4.4, Material.SNOW_BLOCK);
        sphere(blocks, 11.5, 3.4, Material.SNOW_BLOCK);
        sphere(blocks, 16.8, 2.6, Material.SNOW_BLOCK);

        // Шарф — внешнее кольцо слоя на стыке среднего кома и головы
        blocks.replaceAll((position, material) -> position.y() == 14 && horizontal(position) > 1.5 ? Material.RED_WOOL : material);
        blocks.put(new ImmutableVector3i(2, 13, front(blocks, 2, 13) - 1), Material.RED_WOOL);
        blocks.put(new ImmutableVector3i(2, 12, front(blocks, 2, 12) - 1), Material.RED_WOOL);

        // Шляпа: поля и тулья
        disk(blocks, 19, 2.6, Material.BLACK_CONCRETE);
        disk(blocks, 20, 1.6, Material.BLACK_CONCRETE);
        disk(blocks, 21, 1.6, Material.BLACK_CONCRETE);

        // Лицо: глаза, нос-морковка, рот
        onFront(blocks, -1, 17, Material.COAL_BLOCK);
        onFront(blocks, 1, 17, Material.COAL_BLOCK);
        int noseZ = front(blocks, 0, 16);
        blocks.put(new ImmutableVector3i(0, 16, noseZ - 1), Material.ORANGE_CONCRETE);
        blocks.put(new ImmutableVector3i(0, 16, noseZ - 2), Material.ORANGE_TERRACOTTA);
        for (int x = -1; x <= 1; x++) {
            onFront(blocks, x, 15, Material.COAL_BLOCK);
        }

        // Пуговицы
        for (int y : new int[]{9, 11, 13}) {
            onFront(blocks, 0, y, Material.COAL_BLOCK);
        }
        for (int y : new int[]{3, 6}) {
            onFront(blocks, 0, y, Material.COAL_BLOCK);
        }

        // Руки-ветки
        for (int side : new int[]{-1, 1}) {
            for (int x = 4; x <= 6; x++) {
                blocks.put(new ImmutableVector3i(side * x, 12, 0), Material.DARK_OAK_FENCE);
            }
            blocks.put(new ImmutableVector3i(side * 7, 13, 0), Material.DARK_OAK_FENCE);
        }

        Map<ImmutableVector3i, Material> rotated = new LinkedHashMap<>();
        blocks.forEach((position, material) -> rotated.put(rotate(position, rotation), material));
        return rotated;
    }

    private static void sphere(Map<ImmutableVector3i, Material> blocks, double centerY, double radius, Material material) {
        int r = (int) Math.ceil(radius);
        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                for (int y = (int) Math.floor(centerY - radius); y <= Math.ceil(centerY + radius); y++) {
                    double dy = y + 0.5 - centerY;
                    if (x * x + z * z + dy * dy <= radius * radius && y >= 0) {
                        blocks.put(new ImmutableVector3i(x, y, z), material);
                    }
                }
            }
        }
    }

    private static void disk(Map<ImmutableVector3i, Material> blocks, int y, double radius, Material material) {
        int r = (int) Math.ceil(radius);
        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                if (x * x + z * z <= radius * radius) {
                    blocks.put(new ImmutableVector3i(x, y, z), material);
                }
            }
        }
    }

    private static double horizontal(ImmutableVector3i position) {
        return Math.sqrt(position.x() * position.x() + position.z() * position.z());
    }

    /**
     * Самый передний (минимальный z) блок постройки в столбце x, y.
     */
    private static int front(Map<ImmutableVector3i, Material> blocks, int x, int y) {
        int front = 0;
        for (ImmutableVector3i position : blocks.keySet()) {
            if (position.x() == x && position.y() == y) {
                front = Math.min(front, position.z());
            }
        }
        return front;
    }

    private static void onFront(Map<ImmutableVector3i, Material> blocks, int x, int y, Material material) {
        blocks.put(new ImmutableVector3i(x, y, front(blocks, x, y)), material);
    }

    /**
     * Поворот на сетке вокруг центра блока (0, 0): блоки не сдвигаются на полклетки.
     */
    static ImmutableVector3i rotate(ImmutableVector3i position, int rotation) {
        return switch (Math.floorMod(rotation, 360)) {
            case 90 -> new ImmutableVector3i(-position.z(), position.y(), position.x());
            case 180 -> new ImmutableVector3i(-position.x(), position.y(), -position.z());
            case 270 -> new ImmutableVector3i(position.z(), position.y(), -position.x());
            default -> position;
        };
    }
}
