package me.panooga.snowman.logic;

/**
 * Очки бывают дробными (0,1 за снежок), но хранятся целым числом сотых: сумма тысяч сдач
 * по 0,1 в double копила бы ошибку, и у двоих с равным вкладом очки разошлись бы в последнем знаке.
 */
public final class Points {

    public static final int SCALE = 100;

    private Points() {
    }

    /**
     * 0.1 из конфига → 10 сотых. Точность — две цифры после запятой, лишнее округляется.
     */
    public static long fromConfig(double value) {
        return Math.max(0, Math.round(value * SCALE));
    }

    /**
     * Для игроков: «130 820», «12,5», «0,64» — без лишних нулей после запятой, тысячи через пробел.
     */
    public static String format(long hundredths) {
        boolean negative = hundredths < 0;
        long value = Math.abs(hundredths);
        long whole = value / SCALE;
        long fraction = value % SCALE;
        StringBuilder text = new StringBuilder(Long.toString(whole));
        for (int i = text.length() - 3; i > 0; i -= 3) {
            text.insert(i, ' ');
        }
        if (fraction != 0) {
            text.append(',').append(fraction % 10 == 0 ? Long.toString(fraction / 10) : String.format("%02d", fraction));
        }
        return negative ? "-" + text : text.toString();
    }
}
