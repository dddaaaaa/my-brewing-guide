package me.panooga.snowman.site;

import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.math.transform.AffineTransform;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import dev.thorinwasher.blockanimator.worldedit.PaperClipboardBlockSupplier;
import org.bukkit.Location;
import org.bukkit.block.data.BlockData;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Чтение .schem через WorldEdit. Вынесено в отдельный класс: его классы WorldEdit загружаются, только когда
 * схематика действительно задана, — со встроенным снеговиком плагин работает и без WorldEdit.
 */
final class SchematicLoader {

    private SchematicLoader() {
    }

    static Map<ImmutableVector3i, BlockData> load(File file, Location origin, int rotation) throws Exception {
        ClipboardFormat format = ClipboardFormats.findByFile(file);
        if (format == null) {
            throw new IOException("Unknown schematic format");
        }
        Clipboard clipboard;
        try (InputStream input = new FileInputStream(file); ClipboardReader reader = format.getReader(input)) {
            clipboard = reader.read();
        }
        // Как //rotate: WorldEdit поворачивает буфер на минус угол
        PaperClipboardBlockSupplier supplier = new PaperClipboardBlockSupplier(clipboard, origin, new AffineTransform().rotateY(-rotation));
        Map<ImmutableVector3i, BlockData> blocks = new LinkedHashMap<>();
        for (ImmutableVector3i position : supplier.getPositions()) {
            blocks.put(position, supplier.getBlock(position));
        }
        return blocks;
    }
}
