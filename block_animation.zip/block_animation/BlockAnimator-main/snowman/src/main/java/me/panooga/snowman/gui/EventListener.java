package me.panooga.snowman.gui;

import me.panooga.snowman.SnowmanPlugin;
import me.panooga.snowman.event.SnowmanEvent;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Firework;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;

import java.util.List;

public final class EventListener implements Listener {

    private final SnowmanPlugin plugin;
    private final SnowmanEvent event;

    public EventListener(SnowmanPlugin plugin, SnowmanEvent event) {
        this.plugin = plugin;
        this.event = event;
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent click) {
        if (!(click.getView().getTopInventory().getHolder() instanceof DonateMenu menu)) {
            return;
        }
        // Отменяем всё, включая shift-клик из своего инвентаря: в меню ничего нельзя положить или забрать
        click.setCancelled(true);
        if (click.getClickedInventory() == click.getView().getTopInventory()) {
            menu.click(click.getRawSlot(), click.getClick());
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent drag) {
        if (drag.getView().getTopInventory().getHolder() instanceof DonateMenu) {
            drag.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent interact) {
        if (interact.getAction() != Action.RIGHT_CLICK_BLOCK || interact.getHand() != EquipmentSlot.HAND
                || interact.getClickedBlock() == null || !event.isDonationBlock(interact.getClickedBlock())) {
            return;
        }
        interact.setCancelled(true);
        DonateMenu.open(event, interact.getPlayer());
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent breakEvent) {
        if (event.isProtected(breakEvent.getBlock()) && !breakEvent.getPlayer().hasPermission("snowman.admin")) {
            breakEvent.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onPlace(BlockPlaceEvent place) {
        if (event.isProtected(place.getBlockPlaced()) && !place.getPlayer().hasPermission("snowman.admin")) {
            place.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent explode) {
        explode.blockList().removeIf(event::isProtected);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent explode) {
        explode.blockList().removeIf(event::isProtected);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent piston) {
        if (anyProtected(piston.getBlocks(), piston.getDirection()) || event.isProtected(piston.getBlock().getRelative(piston.getDirection()))) {
            piston.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent piston) {
        if (anyProtected(piston.getBlocks(), piston.getDirection())) {
            piston.setCancelled(true);
        }
    }

    /**
     * Защищённым считается и сдвигаемый блок, и клетка, куда его сдвинут: поршнем можно и вытолкнуть снег, и вдавить блок в постройку.
     */
    private boolean anyProtected(List<Block> blocks, BlockFace direction) {
        for (Block block : blocks) {
            if (event.isProtected(block) || event.isProtected(block.getRelative(direction))) {
                return true;
            }
        }
        return false;
    }

    @EventHandler(ignoreCancelled = true)
    public void onFireworkDamage(EntityDamageByEntityEvent damage) {
        if (damage.getDamager() instanceof Firework firework && event.isCelebrationFirework(firework)) {
            damage.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent quit) {
        event.forgetBarViewer(quit.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent join) {
        // С задержкой: сразу после входа часть команд выдачи (give, эффекты) ещё не видит игрока полностью
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (join.getPlayer().isOnline()) {
                event.deliverPendingRewards(join.getPlayer());
            }
        }, 40);
    }
}
