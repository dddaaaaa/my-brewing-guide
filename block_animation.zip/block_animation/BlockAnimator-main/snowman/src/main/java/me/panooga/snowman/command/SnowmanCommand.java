package me.panooga.snowman.command;

import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import me.panooga.snowman.SnowmanPlugin;
import me.panooga.snowman.config.Messages;
import me.panooga.snowman.event.SnowmanEvent;
import me.panooga.snowman.gui.DonateMenu;
import me.panooga.snowman.logic.Contributions;
import me.panooga.snowman.logic.Points;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Locale;

/**
 * /snowman — меню сдачи (рядом с точкой сдачи), /snowman top — таблица вкладов.
 * Остальное — для администратора (snowman.admin).
 */
public final class SnowmanCommand implements TabExecutor {

    private static final List<String> PLAYER_COMMANDS = List.of("top", "help");
    private static final List<String> ADMIN_COMMANDS = List.of("setorigin", "setdonation", "setdrift", "setleaderboard", "start", "skip", "keep", "reset", "reload", "info");

    private final SnowmanPlugin plugin;
    private final SnowmanEvent event;

    public SnowmanCommand(SnowmanPlugin plugin, SnowmanEvent event) {
        this.plugin = plugin;
        this.event = event;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        if (ADMIN_COMMANDS.contains(sub) && !sender.hasPermission("snowman.admin")) {
            Messages.send(sender, "no-permission");
            return true;
        }
        switch (sub) {
            case "" -> openMenu(sender);
            case "top" -> top(sender);
            case "setorigin" -> {
                if (args.length >= 4) {
                    Location location = parseLocation(sender, args, true);
                    if (location != null) {
                        event.setOrigin(sender, location);
                    }
                } else if (sender instanceof Player player) {
                    event.setOrigin(sender, player.getLocation());
                } else {
                    Messages.send(sender, "admin-coordinates-usage");
                }
            }
            case "setdonation" -> {
                if (args.length >= 5) {
                    Location location = parseLocation(sender, args, false);
                    if (location != null) {
                        event.setDonation(sender, location.getBlock());
                    }
                    return true;
                }
                if (!(sender instanceof Player player)) {
                    Messages.send(sender, "admin-coordinates-usage");
                    return true;
                }
                Block target = player.getTargetBlockExact(6);
                if (target == null || target.getType().isAir()) {
                    Messages.send(sender, "admin-look-at-block");
                } else {
                    event.setDonation(sender, target);
                }
            }
            case "setdrift" -> setDrift(sender, args);
            case "setleaderboard" -> setLeaderboard(sender, args);
            case "start" -> event.start(sender);
            case "skip" -> event.skip(sender);
            case "keep" -> {
                if (args.length > 1 && args[1].equalsIgnoreCase("confirm")) {
                    event.keep(sender);
                } else {
                    Messages.send(sender, "admin-keep-confirm");
                }
            }
            case "reset" -> {
                if (args.length > 1 && args[1].equalsIgnoreCase("confirm")) {
                    event.reset(sender);
                } else {
                    Messages.send(sender, "admin-reset-confirm");
                }
            }
            case "reload" -> {
                if (plugin.reload()) {
                    Messages.send(sender, "admin-reloaded");
                } else {
                    Messages.send(sender, "admin-reload-building");
                }
            }
            case "info" -> info(sender);
            default -> help(sender);
        }
        return true;
    }

    /**
     * /snowman setdrift <1|2> — там, где стоит админ; с координатами — из консоли; /snowman setdrift auto — по бокам от постройки.
     */
    private void setDrift(CommandSender sender, String[] args) {
        String which = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
        if (which.equals("auto")) {
            event.setDriftPoint(sender, -1, null);
            return;
        }
        if (!which.equals("1") && !which.equals("2")) {
            Messages.send(sender, "admin-drift-usage");
            return;
        }
        int index = Integer.parseInt(which) - 1;
        if (args.length >= 5) {
            // Сдвигаем аргументы: parseLocation ждёт мир вторым словом, как у setorigin
            String[] shifted = new String[args.length - 1];
            System.arraycopy(args, 1, shifted, 0, shifted.length);
            Location location = parseLocation(sender, shifted, true);
            if (location != null) {
                event.setDriftPoint(sender, index, location);
            }
        } else if (sender instanceof Player player) {
            event.setDriftPoint(sender, index, player.getLocation());
        } else {
            Messages.send(sender, "admin-drift-usage");
        }
    }

    /**
     * /snowman setleaderboard — низ таблицы на уровне глаз админа; auto — над точкой сдачи; из консоли — координаты.
     */
    private void setLeaderboard(CommandSender sender, String[] args) {
        if (args.length > 1 && args[1].equalsIgnoreCase("auto")) {
            event.setLeaderboard(sender, null);
            return;
        }
        if (args.length >= 5) {
            World world = Bukkit.getWorld(args[1]);
            if (world == null) {
                Messages.send(sender, "admin-unknown-world", "world", args[1]);
                return;
            }
            try {
                float yaw = args.length > 5 ? Float.parseFloat(args[5]) : 0;
                event.setLeaderboard(sender, new Location(world, Double.parseDouble(args[2]), Double.parseDouble(args[3]), Double.parseDouble(args[4]), yaw, 0));
            } catch (NumberFormatException e) {
                Messages.send(sender, "admin-leaderboard-usage");
            }
        } else if (sender instanceof Player player) {
            Location eyes = player.getEyeLocation();
            // Поворот — куда смотрит админ: таблицу будут читать те, кто стоит перед ним
            event.setLeaderboard(sender, new Location(eyes.getWorld(), eyes.getX(), eyes.getY(), eyes.getZ(), Math.round(eyes.getYaw()), 0));
        } else {
            Messages.send(sender, "admin-leaderboard-usage");
        }
    }

    private void openMenu(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            help(sender);
            return;
        }
        if (!event.isNearDonation(player) && !player.hasPermission("snowman.admin")) {
            Location donation = event.donation();
            if (donation == null || event.state() == SnowmanEvent.State.IDLE) {
                Messages.send(player, "donate-closed");
            } else {
                Messages.send(player, "donate-come-closer", "x", donation.getBlockX(), "y", donation.getBlockY(), "z", donation.getBlockZ());
            }
            return;
        }
        DonateMenu.open(event, player);
    }

    private void top(CommandSender sender) {
        List<Contributions.Entry> ranking = event.contributions().ranking();
        if (ranking.isEmpty()) {
            Messages.send(sender, "top-empty");
            return;
        }
        Messages.send(sender, "top-header");
        for (int i = 0; i < Math.min(10, ranking.size()); i++) {
            Contributions.Entry entry = ranking.get(i);
            sender.sendMessage(Messages.get("top-line", "place", i + 1, "player", entry.name(), "points", Points.format(entry.points()), "items", entry.items()));
        }
        if (sender instanceof Player player) {
            int place = event.contributions().place(player.getUniqueId());
            if (place > 10) {
                Contributions.Entry self = event.contributions().get(player.getUniqueId()).orElseThrow();
                sender.sendMessage(Messages.get("top-self", "place", place, "points", Points.format(self.points())));
            }
        }
    }

    private void info(CommandSender sender) {
        Location origin = event.origin();
        Location donation = event.donation();
        Messages.send(sender, "info",
                "state", Messages.raw("state-" + event.state().name().toLowerCase(Locale.ROOT)),
                "level", event.levelName(),
                "number", event.level() + 1,
                "total", event.config().levels().size(),
                "percent", (int) Math.floor(event.progress().fraction() * 100),
                "players", event.contributions().ranking().size(),
                "build", event.state() == SnowmanEvent.State.WAITING ? event.buildDate() + " " + event.buildTime() : "—",
                "origin", origin == null ? "—" : format(origin),
                "donation", donation == null ? "—" : format(donation),
                "blocks", event.site() == null ? 0 : event.site().blocks().size(),
                "drift1", event.drift() == null ? "—" : format(event.drift().firstCenter()),
                "drift2", event.drift() == null ? "—" : format(event.drift().secondCenter()));
    }

    /**
     * {@code <мир> <x> <y> <z>}; для места постройки можно {@code <мир> <x> <z>} — тогда встаёт на поверхность.
     * Нужно, чтобы готовить ивент из консоли и ставить место по точным координатам.
     */
    private static Location parseLocation(CommandSender sender, String[] args, boolean allowGround) {
        World world = Bukkit.getWorld(args[1]);
        if (world == null) {
            Messages.send(sender, "admin-unknown-world", "world", args[1]);
            return null;
        }
        try {
            if (args.length == 4 && allowGround) {
                int x = Integer.parseInt(args[2]);
                int z = Integer.parseInt(args[3]);
                return new Location(world, x, world.getHighestBlockYAt(x, z) + 1, z);
            }
            return new Location(world, Integer.parseInt(args[2]), Integer.parseInt(args[3]), Integer.parseInt(args[4]));
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            Messages.send(sender, "admin-coordinates-usage");
            return null;
        }
    }

    private static String format(ImmutableVector3i position) {
        return position.x() + " " + position.y() + " " + position.z();
    }

    private static String format(Location location) {
        return location.getWorld().getName() + " " + location.getBlockX() + " " + location.getBlockY() + " " + location.getBlockZ();
    }

    private void help(CommandSender sender) {
        Messages.send(sender, "help");
        if (sender.hasPermission("snowman.admin")) {
            sender.sendMessage(Messages.get("help-admin"));
        }
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            List<String> options = sender.hasPermission("snowman.admin")
                    ? java.util.stream.Stream.concat(PLAYER_COMMANDS.stream(), ADMIN_COMMANDS.stream()).toList()
                    : PLAYER_COMMANDS;
            return options.stream().filter(option -> option.startsWith(prefix)).toList();
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("reset") || args[0].equalsIgnoreCase("keep")) && sender.hasPermission("snowman.admin")) {
            return List.of("confirm");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("setleaderboard") && sender.hasPermission("snowman.admin")) {
            return List.of("auto");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("setdrift") && sender.hasPermission("snowman.admin")) {
            return java.util.stream.Stream.of("1", "2", "auto").filter(option -> option.startsWith(args[1].toLowerCase(Locale.ROOT))).toList();
        }
        return List.of();
    }
}
