plugins {
    id("java")
    id("com.gradleup.shadow") version "8.3.9"
}

group = "me.panooga"
version = "1.0.0"

repositories {
    mavenCentral()
    maven {
        url = uri("https://repo.papermc.io/repository/maven-public/")
    }
    maven("https://maven.enginehub.org/repo/")
}

java.toolchain {
    languageVersion = JavaLanguageVersion.of(21)
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
    // WorldEdit нужен только для своих .schem; встроенный снеговик работает и без него
    compileOnly("com.sk89q.worldedit:worldedit-core:7.3.19")
    compileOnly("com.sk89q.worldedit:worldedit-bukkit:7.3.19")
    implementation(project(":api"))
    implementation(project(":paper"))
    implementation(project(":worldedit"))

    testImplementation(platform("org.junit:junit-bom:5.10.0"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    testImplementation("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
}

tasks {
    test {
        useJUnitPlatform()
        // MessagesTest читает исходники и messages.yml относительно модуля
        workingDir = projectDir
    }

    processResources {
        filesMatching("plugin.yml") { expand("version" to project.version) }
    }

    shadowJar {
        archiveFileName.set("SnowmanEvent-${project.version}.jar")
        // Другой плагин может везти свою копию библиотеки — переносим, чтобы классы не столкнулись
        relocate("dev.thorinwasher.blockanimator", "me.panooga.snowman.libs.blockanimator")
        dependencies {
            include(project(":api"))
            include(project(":paper"))
            include(project(":worldedit"))
        }
    }

    build {
        dependsOn(shadowJar)
    }

    jar {
        enabled = false
    }
}
