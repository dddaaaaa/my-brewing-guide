package dev.thorinwasher.blockanimator.paper.blockanimator;

import dev.thorinwasher.blockanimator.api.animator.BlockAnimator;
import dev.thorinwasher.blockanimator.api.supplier.BlockSupplier;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.BlockDisplay;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3d;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Moves blocks as {@link BlockDisplay} entities. Movement is interpolated on the client, so the server only has to
 * send a position every {@code updateInterval} ticks while the animation still looks smooth.
 */
public abstract class BlockDisplayAnimator implements BlockAnimator<BlockData> {

    // Больше клиент не принимает для teleport_duration
    public static final int MAX_UPDATE_INTERVAL = 59;

    protected final World world;
    private final int updateInterval;
    private final Map<ImmutableVector3i, MovingDisplay> displays = new HashMap<>();

    /**
     * @param updateInterval how often (in ticks) a moving block sends its position, 1 sends every tick.
     *                       Higher values save network and tracker load, the client interpolates in between
     */
    protected BlockDisplayAnimator(World world, int updateInterval) {
        if (updateInterval < 1 || updateInterval > MAX_UPDATE_INTERVAL) {
            throw new IllegalArgumentException("updateInterval has to be between 1 and " + MAX_UPDATE_INTERVAL);
        }
        this.world = world;
        this.updateInterval = updateInterval;
    }

    @Override
    public void blockMove(ImmutableVector3i identifier, Vector3d to, BlockSupplier<BlockData> blockSupplier, @Nullable Matrix4f transform) {
        MovingDisplay display = displays.get(identifier);
        if (display == null) {
            displays.put(identifier, spawn(blockSupplier.getBlock(identifier), to, transform));
            return;
        }
        if (++display.moves % updateInterval != 0) {
            return;
        }
        display.update(toLocation(to), transform);
    }

    @Override
    public void blockDestroy(ImmutableVector3i identifier) {
        world.getBlockAt(identifier.x(), identifier.y(), identifier.z()).setType(Material.AIR);
    }

    /**
     * Puts the display of the block exactly at its final position with no transformation.
     */
    protected void snapToBlock(ImmutableVector3i identifier, BlockSupplier<BlockData> blockSupplier) {
        Vector3d target = identifier.asVector3d();
        MovingDisplay display = displays.get(identifier);
        if (display == null) {
            displays.put(identifier, spawn(blockSupplier.getBlock(identifier), target, null));
            return;
        }
        display.update(toLocation(target), null);
    }

    protected void removeDisplay(ImmutableVector3i identifier) {
        MovingDisplay display = displays.remove(identifier);
        if (display != null) {
            display.entity.remove();
        }
    }

    protected void removeAllDisplays() {
        displays.values().forEach(display -> display.entity.remove());
        displays.clear();
    }

    private MovingDisplay spawn(BlockData blockData, Vector3d position, @Nullable Matrix4f transform) {
        BlockDisplay entity = world.spawn(toLocation(position), BlockDisplay.class, blockDisplay -> {
            blockDisplay.setBlock(blockData);
            // Сущности временные: после рестарта или выгрузки чанка они не должны остаться висеть в мире
            blockDisplay.setPersistent(false);
            blockDisplay.setTeleportDuration(updateInterval);
            blockDisplay.setInterpolationDuration(updateInterval);
            if (transform != null) {
                blockDisplay.setTransformationMatrix(transform);
            }
        });
        return new MovingDisplay(entity, transform);
    }

    private Location toLocation(Vector3d position) {
        return new Location(world, position.x, position.y, position.z);
    }

    private static final class MovingDisplay {
        private final BlockDisplay entity;
        private @Nullable Matrix4f transform;
        private int moves;

        private MovingDisplay(BlockDisplay entity, @Nullable Matrix4f transform) {
            this.entity = entity;
            this.transform = transform;
        }

        private void update(Location location, @Nullable Matrix4f newTransform) {
            entity.teleport(location);
            // Метаданные трансформации шлём только при изменении: без ResizeTransformation это ни одного пакета
            if (!Objects.equals(transform, newTransform)) {
                entity.setInterpolationDelay(0);
                entity.setTransformationMatrix(newTransform == null ? new Matrix4f() : newTransform);
                transform = newTransform;
            }
        }
    }
}
