package dev.thorinwasher.blockanimator.paper.blockanimator;

import dev.thorinwasher.blockanimator.api.supplier.BlockSupplier;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;

import java.util.ArrayList;
import java.util.List;

/**
 * Keeps arrived blocks as displays and places them in batches of {@code maxEntities}, which avoids lighting and
 * physics updates every tick.
 */
public class PlaceBlocksAfterBlockAnimator extends BlockDisplayAnimator {

    private final int maxEntities;
    private final List<ImmutableVector3i> waitingForPlacement = new ArrayList<>();

    public PlaceBlocksAfterBlockAnimator(World world, int maxEntities) {
        this(world, maxEntities, 1);
    }

    public PlaceBlocksAfterBlockAnimator(World world, int maxEntities, int updateInterval) {
        super(world, updateInterval);
        this.maxEntities = Math.max(1, maxEntities);
    }

    @Override
    public void blockPlace(ImmutableVector3i identifier, BlockSupplier<BlockData> blockSupplier) {
        snapToBlock(identifier, blockSupplier);
        waitingForPlacement.add(identifier);
        if (waitingForPlacement.size() >= maxEntities) {
            placeWaitingBlocks(blockSupplier);
        }
    }

    private void placeWaitingBlocks(BlockSupplier<BlockData> blockSupplier) {
        if (waitingForPlacement.isEmpty()) {
            return;
        }
        blockSupplier.placeBlocks(waitingForPlacement);
        waitingForPlacement.forEach(this::removeDisplay);
        waitingForPlacement.clear();
    }

    @Override
    public void finishAnimation(BlockSupplier<BlockData> blockSupplier) {
        placeWaitingBlocks(blockSupplier);
        removeAllDisplays();
    }
}
