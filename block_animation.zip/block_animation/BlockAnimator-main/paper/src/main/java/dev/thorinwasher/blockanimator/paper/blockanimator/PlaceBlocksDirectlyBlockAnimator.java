package dev.thorinwasher.blockanimator.paper.blockanimator;

import dev.thorinwasher.blockanimator.api.supplier.BlockSupplier;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;

/**
 * Places every block as soon as it arrives.
 */
public class PlaceBlocksDirectlyBlockAnimator extends BlockDisplayAnimator {

    public PlaceBlocksDirectlyBlockAnimator(World world) {
        this(world, 1);
    }

    public PlaceBlocksDirectlyBlockAnimator(World world, int updateInterval) {
        super(world, updateInterval);
    }

    @Override
    public void blockPlace(ImmutableVector3i identifier, BlockSupplier<BlockData> blockSupplier) {
        // Сначала блок, потом удаление сущности — иначе на тик видна дыра
        blockSupplier.placeBlock(identifier);
        removeDisplay(identifier);
    }

    @Override
    public void finishAnimation(BlockSupplier<BlockData> blockSupplier) {
        removeAllDisplays();
    }
}
