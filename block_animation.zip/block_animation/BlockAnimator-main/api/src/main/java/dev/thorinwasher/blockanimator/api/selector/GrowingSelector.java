package dev.thorinwasher.blockanimator.api.selector;

import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import dev.thorinwasher.blockanimator.api.util.Directions;

import java.util.*;

/**
 * Grows the structure from a random seed outwards, layer by layer. When a connected part is complete, a new seed
 * is picked among the remaining blocks.
 */
public class GrowingSelector implements BlockSelector {

    private final Random random;

    public GrowingSelector() {
        this(new Random());
    }

    public GrowingSelector(Random random) {
        this.random = random;
    }

    @Override
    public CompiledBlockSelector compile(List<ImmutableVector3i> blocks) {
        // Всё состояние локально: раньше оно жило в полях, и повторный compile() падал или выдавал пустоту
        Set<ImmutableVector3i> remaining = new HashSet<>(blocks);
        SeedPicker seedPicker = new SeedPicker(remaining, random);
        LinkedList<List<ImmutableVector3i>> output = new LinkedList<>();
        List<ImmutableVector3i> open = new ArrayList<>();
        while (!remaining.isEmpty()) {
            if (open.isEmpty()) {
                // Зерно выдаём сразу: раньше оно ждало, пока до него дорастёт сосед, и одиночный блок
                // без соседей не выдавался никогда — компиляция зависала
                ImmutableVector3i seed = seedPicker.next(remaining);
                remaining.remove(seed);
                open.add(seed);
                output.add(List.of(seed));
                continue;
            }
            List<ImmutableVector3i> step = new ArrayList<>();
            for (ImmutableVector3i block : open) {
                for (ImmutableVector3i direction : Directions.DIRECTIONS) {
                    ImmutableVector3i neighbour = block.add(direction);
                    if (remaining.remove(neighbour)) {
                        step.add(neighbour);
                    }
                }
            }
            if (!step.isEmpty()) {
                output.add(step);
            }
            open = step;
        }
        return new CompiledBlockSelector(output);
    }
}
