package dev.thorinwasher.blockanimator.api.timer;

import dev.thorinwasher.blockanimator.api.selector.CompiledBlockSelector;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;

import java.util.List;

public interface BlockTimer {

    /**
     * Called at the start of every compilation, so one timer instance can be reused.
     */
    default void reset() {
    }

    boolean hasNext(int totalBlockAmount);

    List<ImmutableVector3i> fetch(CompiledBlockSelector blockSelector, int totalBlockAmount);
}
