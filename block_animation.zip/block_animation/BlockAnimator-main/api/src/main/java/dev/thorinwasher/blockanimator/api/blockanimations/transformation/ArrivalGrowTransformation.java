package dev.thorinwasher.blockanimator.api.blockanimations.transformation;

import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;

/**
 * Keeps the block small while it flies and grows it to full size right before it arrives, so the real block appears
 * exactly where a full-sized display already is. Optionally spins the block around its vertical axis, slowing down
 * to rest on arrival.
 */
public class ArrivalGrowTransformation implements BlockTransformation {

    private final float flyScale;
    private final double growStart;
    private final double spinTurns;

    /**
     * @param flyScale  block size while flying, 1 is a full block
     * @param growStart path completion (0..1) at which the block starts growing to full size
     * @param spinTurns full turns around the vertical axis over the whole path, 0 disables spinning
     */
    public ArrivalGrowTransformation(float flyScale, double growStart, double spinTurns) {
        if (growStart < 0 || growStart >= 1) {
            throw new IllegalArgumentException("growStart has to be in [0, 1)");
        }
        this.flyScale = flyScale;
        this.growStart = growStart;
        this.spinTurns = spinTurns;
    }

    public ArrivalGrowTransformation(float flyScale, double growStart) {
        this(flyScale, growStart, 0);
    }

    @Override
    public @NotNull Matrix4f getTransform(double pathCompletion) {
        double completion = Math.max(0, Math.min(1, pathCompletion));
        float scale = flyScale;
        if (completion > growStart) {
            double growth = (completion - growStart) / (1 - growStart);
            // smoothstep: рост начинается и заканчивается плавно, без рывка в момент появления блока
            double eased = growth * growth * (3 - 2 * growth);
            scale = (float) (flyScale + (1 - flyScale) * eased);
        }
        // Вращение затухает к прилёту, чтобы блок встал ровно по сетке
        float angle = (float) (spinTurns * 2 * Math.PI * (1 - completion) * (1 - completion));
        Matrix4f matrix = new Matrix4f().translate(0.5F, 0.5F, 0.5F);
        if (angle != 0) {
            matrix.rotateY(angle);
        }
        return matrix.scale(scale).translate(-0.5F, -0.5F, -0.5F);
    }
}
