package dev.thorinwasher.blockanimator.api.blockanimations;

import dev.thorinwasher.blockanimator.api.animation.BlockAnimationFrame;
import dev.thorinwasher.blockanimator.api.blockanimations.pathcompletion.PathCompletionSupplier;
import dev.thorinwasher.blockanimator.api.blockanimations.transformation.BlockTransformation;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import org.joml.GeometryUtils;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class BlockMoveQuadraticBezier implements BlockMoveAnimation {

    private static final int LENGTH_SAMPLES = 20;
    private final Function<Vector3d, Vector3d> from;
    private final PathCompletionSupplier pathCompletionSupplier;
    private static final Random RANDOM = new Random();
    private final BiFunction<Vector3d, Vector3d, Vector3d> controlPointFunction;
    private BlockTransformation blockTransform;

    /**
     * The control point is moved from the start point by the given length in a random direction orthogonal to the path.
     */
    public BlockMoveQuadraticBezier(Function<Vector3d, Vector3d> from, PathCompletionSupplier pathCompletionSupplier, Supplier<Double> controlPointLengthSupplier) {
        this(from, pathCompletionSupplier, (start, end) -> randomOrthogonalControlPoint(start, end, controlPointLengthSupplier.get()), true);
    }

    public BlockMoveQuadraticBezier(Vector3d from, PathCompletionSupplier pathCompletionSupplier, Supplier<Double> controlPointLengthSupplier) {
        this(ignored -> from, pathCompletionSupplier, controlPointLengthSupplier);
    }

    private BlockMoveQuadraticBezier(Function<Vector3d, Vector3d> from, PathCompletionSupplier pathCompletionSupplier,
                                     BiFunction<Vector3d, Vector3d, Vector3d> controlPointFunction, boolean ignored) {
        this.from = from;
        this.pathCompletionSupplier = pathCompletionSupplier;
        this.controlPointFunction = controlPointFunction;
    }

    /**
     * @param controlPoint receives the start and the end of the path and returns the control point of the curve,
     *                     for example the middle of the path lifted up to make blocks fly in an arc
     */
    public static BlockMoveQuadraticBezier withControlPoint(Function<Vector3d, Vector3d> from, PathCompletionSupplier pathCompletionSupplier,
                                                            BiFunction<Vector3d, Vector3d, Vector3d> controlPoint) {
        return new BlockMoveQuadraticBezier(from, pathCompletionSupplier, controlPoint, true);
    }

    @Override
    public CompiledBlockMoveAnimation compile(ImmutableVector3i identifier) {
        Vector3d to = identifier.asVector3d();
        Vector3d fromValue = from.apply(to);
        Vector3d controlPoint = new Vector3d(controlPointFunction.apply(new Vector3d(fromValue), new Vector3d(to)));
        double pathLength = bezierCurveLength(fromValue, to, controlPoint);
        List<Double> steps = pathCompletionSupplier.compile(pathLength);
        List<BlockAnimationFrame> frames = new ArrayList<>(steps.size() + 1);
        for (double time : steps) {
            // null — единичная матрица; раньше null уходил в Paper-аниматор и ронял его NPE
            Matrix4f matrix4f = blockTransform == null ? null : blockTransform.getTransform(time);
            frames.add(new BlockAnimationFrame(pointAt(fromValue, to, controlPoint, time), BlockMoveType.MOVE, matrix4f));
        }
        frames.add(new BlockAnimationFrame(to, BlockMoveType.PLACE, null));
        return new CompiledBlockMoveAnimation(frames);
    }

    private static Vector3d randomOrthogonalControlPoint(Vector3d from, Vector3d to, double length) {
        Vector3d controlPoint = new Vector3d(from);
        // При совпадении начала и цели normalize() даёт NaN, и блок улетал бы в никуда
        if (from.distanceSquared(to) <= 1.0E-12) {
            return controlPoint;
        }
        Vector3f deltaNorm = new Vector3f(new Vector3d(from).sub(to).normalize());
        Vector3f orthogonal1 = new Vector3f();
        Vector3f orthogonal2 = new Vector3f();
        GeometryUtils.perpendicular(deltaNorm, orthogonal1, orthogonal2);
        double randomRadians = RANDOM.nextDouble(0, 2 * Math.PI);
        Vector3d randomOrthogonal = new Vector3d(orthogonal1).mul(Math.cos(randomRadians)).add(new Vector3d(orthogonal2).mul(Math.sin(randomRadians)));
        return controlPoint.add(randomOrthogonal.mul(length));
    }

    private double bezierCurveLength(Vector3d from, Vector3d to, Vector3d controlPoint) {
        Vector3d previous = new Vector3d(from);
        double length = 0;
        for (int sample = 1; sample <= LENGTH_SAMPLES; sample++) {
            Vector3d point = pointAt(from, to, controlPoint, (double) sample / LENGTH_SAMPLES);
            length += previous.distance(point);
            previous = point;
        }
        return length;
    }

    private static Vector3d pointAt(Vector3d from, Vector3d to, Vector3d controlPoint, double time) {
        double a = (1 - time) * (1 - time);
        double b = 2 * (1 - time) * time;
        double c = time * time;
        return new Vector3d(
                from.x * a + controlPoint.x * b + to.x * c,
                from.y * a + controlPoint.y * b + to.y * c,
                from.z * a + controlPoint.z * b + to.z * c
        );
    }

    public void addBlockTransform(BlockTransformation blockTransformation) {
        this.blockTransform = blockTransformation;
    }
}
