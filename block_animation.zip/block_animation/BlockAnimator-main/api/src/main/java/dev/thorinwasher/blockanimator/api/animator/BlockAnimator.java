package dev.thorinwasher.blockanimator.api.animator;

import dev.thorinwasher.blockanimator.api.supplier.BlockSupplier;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3d;

public interface BlockAnimator<B> {

    /**
     * @param transform the block transformation, null means identity
     */
    void blockMove(ImmutableVector3i identifier, Vector3d to, BlockSupplier<B> blockSupplier, @Nullable Matrix4f transform);

    void blockPlace(ImmutableVector3i identifier, BlockSupplier<B> blockSupplier);

    void blockDestroy(ImmutableVector3i identifier);

    /**
     * Places every block that is still waiting and removes all animation entities. Called exactly once.
     */
    void finishAnimation(BlockSupplier<B> blockSupplier);
}
