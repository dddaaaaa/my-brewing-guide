package dev.thorinwasher.blockanimator.api.selector;

import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Выдаёт случайные ещё не взятые блоки. Список перемешивается один раз и проходится указателем,
 * поэтому все зёрна за всю компиляцию стоят O(n), а не O(n) на каждое зерно, как раньше.
 */
class SeedPicker {

    private final List<ImmutableVector3i> shuffled;
    private int index;

    SeedPicker(Collection<ImmutableVector3i> blocks, Random random) {
        this.shuffled = new ArrayList<>(blocks);
        Collections.shuffle(shuffled, random);
    }

    ImmutableVector3i next(Set<ImmutableVector3i> remaining) {
        while (index < shuffled.size()) {
            ImmutableVector3i candidate = shuffled.get(index++);
            if (remaining.contains(candidate)) {
                return candidate;
            }
        }
        throw new IllegalStateException("No blocks left to seed from");
    }
}
