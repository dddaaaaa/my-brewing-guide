package dev.thorinwasher.blockanimator.api.timer;

import dev.thorinwasher.blockanimator.api.selector.CompiledBlockSelector;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;

import java.util.ArrayList;
import java.util.List;

/**
 * Spreads the start of all block animations evenly over the given amount of ticks.
 */
public class LinearBlockTimer implements BlockTimer {

    private final int ticks;
    private int currentTick = 0;
    private int blocksPulled;
    private boolean exhausted;

    public LinearBlockTimer(int ticks) {
        this.ticks = Math.max(1, ticks);
    }

    @Override
    public void reset() {
        currentTick = 0;
        blocksPulled = 0;
        exhausted = false;
    }

    @Override
    public boolean hasNext(int totalBlockAmount) {
        return !exhausted && totalBlockAmount > blocksPulled;
    }

    @Override
    public List<ImmutableVector3i> fetch(CompiledBlockSelector blockSelector, int totalBlockAmount) {
        // Сколько блоков должно быть запущено к концу этого тика по графику. Раньше условие было >= 0,
        // и каждый тик забиралась лишняя группа — анимация шла быстрее заданного времени
        long scheduled = Math.min(totalBlockAmount, Math.round((double) totalBlockAmount * ++currentTick / ticks));
        List<ImmutableVector3i> blocks = new ArrayList<>();
        while (blocksPulled + blocks.size() < scheduled) {
            List<ImmutableVector3i> next = blockSelector.next();
            if (next.isEmpty()) {
                // Селектор кончился раньше счётчика — без этого флага цикл компиляции был бы вечным
                exhausted = true;
                break;
            }
            blocks.addAll(next);
        }
        blocksPulled += blocks.size();
        return blocks;
    }
}
