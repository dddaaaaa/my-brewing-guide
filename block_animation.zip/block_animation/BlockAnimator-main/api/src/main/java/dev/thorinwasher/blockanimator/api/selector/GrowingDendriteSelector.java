package dev.thorinwasher.blockanimator.api.selector;

import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import dev.thorinwasher.blockanimator.api.util.Directions;

import java.util.*;

/**
 * Grows branches from a random seed. Every grown block keeps growing in the direction it came from, and gets a new
 * random growth direction with the given chance each step.
 */
public class GrowingDendriteSelector implements BlockSelector {

    private final Random random;
    private final double growthDirectionAddChance;

    public GrowingDendriteSelector(double growthDirectionAddChance) {
        this(growthDirectionAddChance, new Random());
    }

    public GrowingDendriteSelector(double growthDirectionAddChance, Random random) {
        this.growthDirectionAddChance = growthDirectionAddChance;
        this.random = random;
    }

    @Override
    public CompiledBlockSelector compile(List<ImmutableVector3i> blocks) {
        Set<ImmutableVector3i> remaining = new HashSet<>(blocks);
        SeedPicker seedPicker = new SeedPicker(remaining, random);
        LinkedList<List<ImmutableVector3i>> points = new LinkedList<>();
        // Только «живые» блоки, у которых есть свободный сосед. Раньше каждый шаг копировал и обходил
        // карту всех выросших блоков — для больших построек это O(n²)
        Map<ImmutableVector3i, Set<ImmutableVector3i>> active = new LinkedHashMap<>();
        while (!remaining.isEmpty()) {
            List<ImmutableVector3i> step = active.isEmpty() ? List.of() : nextStep(active, remaining);
            if (step.isEmpty()) {
                ImmutableVector3i seed = seedPicker.next(remaining);
                remaining.remove(seed);
                active.put(seed, new HashSet<>(Directions.DIRECTIONS));
                points.add(List.of(seed));
            } else {
                points.add(step);
            }
        }
        return new CompiledBlockSelector(points);
    }

    private List<ImmutableVector3i> nextStep(Map<ImmutableVector3i, Set<ImmutableVector3i>> active, Set<ImmutableVector3i> remaining) {
        List<ImmutableVector3i> output = new ArrayList<>();
        Map<ImmutableVector3i, Set<ImmutableVector3i>> grown = new HashMap<>();
        Iterator<Map.Entry<ImmutableVector3i, Set<ImmutableVector3i>>> iterator = active.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<ImmutableVector3i, Set<ImmutableVector3i>> entry = iterator.next();
            ImmutableVector3i block = entry.getKey();
            Set<ImmutableVector3i> directions = entry.getValue();
            for (ImmutableVector3i direction : directions) {
                ImmutableVector3i growth = block.add(direction);
                if (remaining.remove(growth)) {
                    output.add(growth);
                    grown.put(growth, new HashSet<>(Set.of(direction)));
                }
            }
            if (!hasFreeNeighbour(block, remaining)) {
                // Свободных соседей больше не появится — блок больше никогда не вырастет
                iterator.remove();
                continue;
            }
            if (random.nextDouble() < growthDirectionAddChance && directions.size() < Directions.DIRECTIONS.size()) {
                List<ImmutableVector3i> possibleDirectionsToAdd = new ArrayList<>(Directions.DIRECTIONS);
                possibleDirectionsToAdd.removeAll(directions);
                directions.add(possibleDirectionsToAdd.get(random.nextInt(possibleDirectionsToAdd.size())));
            }
        }
        active.putAll(grown);
        return output;
    }

    private static boolean hasFreeNeighbour(ImmutableVector3i block, Set<ImmutableVector3i> remaining) {
        for (ImmutableVector3i direction : Directions.DIRECTIONS) {
            if (remaining.contains(block.add(direction))) {
                return true;
            }
        }
        return false;
    }
}
