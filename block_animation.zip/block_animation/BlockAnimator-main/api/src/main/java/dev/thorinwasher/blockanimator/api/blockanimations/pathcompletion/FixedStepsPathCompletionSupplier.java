package dev.thorinwasher.blockanimator.api.blockanimations.pathcompletion;

import java.util.ArrayList;
import java.util.List;

public class FixedStepsPathCompletionSupplier implements PathCompletionSupplier {

    private final int steps;

    public FixedStepsPathCompletionSupplier(int steps) {
        this.steps = steps;
    }

    @Override
    public List<Double> compile(double pathLength) {
        List<Double> steps = new ArrayList<>(this.steps + 1);
        // Доля пути от длины не зависит; через длину при pathLength = 0 выходило 0/0 = NaN
        for (int step = 0; step < this.steps; step++) {
            steps.add((double) step / this.steps);
        }
        steps.add(1D);
        return steps;
    }
}
