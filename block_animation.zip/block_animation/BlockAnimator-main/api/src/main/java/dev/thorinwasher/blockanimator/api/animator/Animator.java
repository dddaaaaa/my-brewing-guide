package dev.thorinwasher.blockanimator.api.animator;

import dev.thorinwasher.blockanimator.api.animation.Animation;
import dev.thorinwasher.blockanimator.api.animation.AnimationFrame;
import dev.thorinwasher.blockanimator.api.animation.BlockAnimationFrame;
import dev.thorinwasher.blockanimator.api.supplier.BlockSupplier;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Animator<B> {

    private final Animation<B> animation;
    private final BlockAnimator<B> blockAnimator;
    private final List<Runnable> onCompletion = new ArrayList<>();
    private boolean finished;
    // HashSet: emergencyFinish вычитает его из всех позиций, со списком это было O(n²)
    private final Set<ImmutableVector3i> placed = new HashSet<>();

    public Animator(Animation<B> animation, BlockAnimator<B> blockAnimator) {
        this.animation = animation;
        this.blockAnimator = blockAnimator;
    }

    /**
     * @return true when the animation is finished and the ticking task can be cancelled
     */
    public boolean nextTick() {
        if (finished) {
            return true;
        }
        Animation.AnimationStatus status = animation.getStatus();
        if (status == Animation.AnimationStatus.COMPLETED) {
            blockAnimator.finishAnimation(animation.supplier());
            complete();
            return true;
        }
        if (status == Animation.AnimationStatus.COMPILING) {
            return false;
        }
        AnimationFrame frame = animation.getNext();
        BlockSupplier<B> supplier = animation.supplier();
        for (Map.Entry<ImmutableVector3i, BlockAnimationFrame> entry : frame.currentToDestination().entrySet()) {
            ImmutableVector3i identifier = entry.getKey();
            Vector3d position = entry.getValue().position();
            switch (entry.getValue().moveType()) {
                case PLACE -> {
                    blockAnimator.blockPlace(identifier, supplier);
                    placed.add(identifier);
                }
                case MOVE -> blockAnimator.blockMove(identifier, position, supplier, entry.getValue().transform());
                case DESTROY -> blockAnimator.blockDestroy(identifier);
            }
        }
        return false;
    }

    /**
     * Adds a callback that runs once, after the last block has been placed and all animation entities are removed.
     */
    public void addOnCompletion(Runnable runnable) {
        this.onCompletion.add(runnable);
    }

    public boolean isFinished() {
        return finished;
    }

    /**
     * Stops the animation immediately and places every block of the structure. Has to be run on the main thread.
     */
    public void emergencyFinish() {
        if (finished) {
            return;
        }
        animation.cancel();
        BlockSupplier<B> supplier = animation.supplier();
        // Блоки, которые уже долетели, могут ещё лежать в буфере PlaceBlocksAfter: их ставит
        // finishAnimation, заодно убирая все летящие сущности
        blockAnimator.finishAnimation(supplier);
        List<ImmutableVector3i> toPlace = new ArrayList<>();
        for (ImmutableVector3i position : new HashSet<>(supplier.getPositions())) {
            if (!placed.contains(position)) {
                toPlace.add(position);
            }
        }
        supplier.placeBlocks(toPlace);
        complete();
    }

    private void complete() {
        finished = true;
        onCompletion.forEach(Runnable::run);
    }
}
