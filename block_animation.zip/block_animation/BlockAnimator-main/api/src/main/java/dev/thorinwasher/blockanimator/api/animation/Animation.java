package dev.thorinwasher.blockanimator.api.animation;

import dev.thorinwasher.blockanimator.api.blockanimations.CompiledBlockMoveAnimation;
import dev.thorinwasher.blockanimator.api.supplier.BlockSupplier;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import org.jetbrains.annotations.ApiStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

public interface Animation<B> {

    /**
     * HAS TO BE RUN ASYNC!
     */
    void compile();

    /**
     * Stops compilation as soon as possible and drops compiled frames. Safe to call from any thread.
     */
    void cancel();

    @ApiStatus.Internal
    AnimationFrame getNext();

    @ApiStatus.Internal
    static void mergeBlockAnimationToFrames(CompiledBlockMoveAnimation
                                                    compiledBlockMoveAnimation, Map<Integer, AnimationFrame> frames, ImmutableVector3i target, int frame) {
        for (BlockAnimationFrame newPosition : compiledBlockMoveAnimation.frames()) {
            frames.computeIfAbsent(frame, ignored -> new AnimationFrame(new HashMap<>())).currentToDestination().put(target, newPosition);
            frame++;
        }
    }

    /**
     * Поставщик может вернуть одну позицию дважды (например, после поворота схемы),
     * а селекторы и таймеры считают блоки поштучно — с дублями они ждали бы блок, которого не будет.
     */
    @ApiStatus.Internal
    static List<ImmutableVector3i> uniquePositions(BlockSupplier<?> blockSupplier) {
        return new ArrayList<>(new LinkedHashSet<>(blockSupplier.getPositions()));
    }

    @ApiStatus.Internal
    AnimationStatus getStatus();

    @ApiStatus.Internal
    BlockSupplier<B> supplier();

    enum AnimationStatus {
        COMPLETED,
        READY_FOR_ANIMATION,
        COMPILING
    }
}
