package dev.thorinwasher.blockanimator.api;

import dev.thorinwasher.blockanimator.api.animation.Animation;
import dev.thorinwasher.blockanimator.api.animation.AnimationFrame;
import dev.thorinwasher.blockanimator.api.animation.BlockAnimationFrame;
import dev.thorinwasher.blockanimator.api.animation.SequentialAnimation;
import dev.thorinwasher.blockanimator.api.animation.TimerAnimation;
import dev.thorinwasher.blockanimator.api.animator.Animator;
import dev.thorinwasher.blockanimator.api.animator.BlockAnimator;
import dev.thorinwasher.blockanimator.api.blockanimations.BlockMoveLinear;
import dev.thorinwasher.blockanimator.api.blockanimations.BlockMoveQuadraticBezier;
import dev.thorinwasher.blockanimator.api.blockanimations.BlockMoveType;
import dev.thorinwasher.blockanimator.api.blockanimations.CompiledBlockMoveAnimation;
import dev.thorinwasher.blockanimator.api.blockanimations.pathcompletion.ConstantSpeedPathCompletionSupplier;
import dev.thorinwasher.blockanimator.api.blockanimations.pathcompletion.EaseOutCubicPathCompletionSupplier;
import dev.thorinwasher.blockanimator.api.blockanimations.pathcompletion.FixedStepsPathCompletionSupplier;
import dev.thorinwasher.blockanimator.api.blockanimations.transformation.ArrivalGrowTransformation;
import dev.thorinwasher.blockanimator.api.selector.*;
import dev.thorinwasher.blockanimator.api.supplier.BlockSupplier;
import dev.thorinwasher.blockanimator.api.supplier.ImmutableVector3i;
import dev.thorinwasher.blockanimator.api.timer.LinearBlockTimer;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

import java.util.*;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.*;

class FixesTest {

    private static List<ImmutableVector3i> cube(int size) {
        List<ImmutableVector3i> output = new ArrayList<>();
        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                for (int z = 0; z < size; z++) {
                    output.add(new ImmutableVector3i(x, y, z));
                }
            }
        }
        return output;
    }

    /** Куб плюс одиночные блоки без соседей — на них раньше зависал GrowingSelector */
    private static List<ImmutableVector3i> cubeWithIsolated() {
        List<ImmutableVector3i> blocks = cube(6);
        blocks.add(new ImmutableVector3i(20, 0, 0));
        blocks.add(new ImmutableVector3i(-20, 5, 3));
        blocks.add(new ImmutableVector3i(0, 40, 0));
        return blocks;
    }

    private static List<ImmutableVector3i> drain(CompiledBlockSelector selector) {
        List<ImmutableVector3i> output = new ArrayList<>();
        List<ImmutableVector3i> next;
        while (!(next = selector.next()).isEmpty()) {
            output.addAll(next);
        }
        return output;
    }

    private static void assertEachOnce(List<ImmutableVector3i> expected, List<ImmutableVector3i> actual) {
        assertEquals(new HashSet<>(expected).size(), actual.size(), "every block exactly once");
        assertEquals(new HashSet<>(expected), new HashSet<>(actual));
    }

    @Test
    @Timeout(10)
    void selectorsCoverEveryBlockAndAreReusable() {
        List<Supplier<BlockSelector>> selectors = List.of(
                GrowingSelector::new,
                () -> new GrowingDendriteSelector(0.1),
                () -> new GrowingDendriteSelector(0.0),
                BottomFirstSelector::new,
                LayeredBottomFirst::new,
                RandomSpherical::new
        );
        List<ImmutableVector3i> blocks = cubeWithIsolated();
        List<ImmutableVector3i> withDuplicates = new ArrayList<>(blocks);
        withDuplicates.addAll(blocks.subList(0, 10));
        for (Supplier<BlockSelector> factory : selectors) {
            BlockSelector selector = factory.get();
            assertEachOnce(blocks, drain(selector.compile(blocks)));
            // Тот же экземпляр второй раз — раньше Growing*-селекторы ломались
            assertEachOnce(blocks, drain(selector.compile(blocks)));
            if (selector instanceof GrowingSelector || selector instanceof GrowingDendriteSelector) {
                assertEachOnce(blocks, drain(selector.compile(withDuplicates)));
            }
        }
    }

    @Test
    @Timeout(20)
    void dendriteHandlesLargeStructures() {
        List<ImmutableVector3i> blocks = cube(50);
        long start = System.nanoTime();
        List<ImmutableVector3i> result = drain(new GrowingDendriteSelector(0.2).compile(blocks));
        long millis = (System.nanoTime() - start) / 1_000_000;
        assertEachOnce(blocks, result);
        System.out.println("Dendrite, 125000 blocks: " + millis + " ms");
    }

    @Test
    void linearTimerSpreadsBlocksOverTicks() {
        List<ImmutableVector3i> blocks = cube(2); // 8 блоков
        LinearBlockTimer timer = new LinearBlockTimer(40);
        for (int run = 0; run < 2; run++) {
            timer.reset();
            CompiledBlockSelector selector = new BottomFirstSelector().compile(blocks);
            int ticks = 0;
            int pulled = 0;
            while (timer.hasNext(blocks.size())) {
                pulled += timer.fetch(selector, blocks.size()).size();
                ticks++;
                assertTrue(ticks <= 40, "timer must not take longer than the configured ticks");
            }
            assertEquals(8, pulled);
            // Раньше за каждый тик забиралась минимум одна группа и всё кончалось за 8 тиков
            assertTrue(ticks >= 36, "blocks have to be spread over the whole duration, ticks: " + ticks);
        }
    }

    @Test
    @Timeout(5)
    void linearTimerStopsWhenSelectorRunsOut() {
        LinearBlockTimer timer = new LinearBlockTimer(5);
        CompiledBlockSelector selector = new BottomFirstSelector().compile(cube(2));
        int ticks = 0;
        // Счётчик ждёт 100 блоков, а селектор даёт 8
        while (timer.hasNext(100)) {
            timer.fetch(selector, 100);
            ticks++;
        }
        assertTrue(ticks <= 5);
    }

    @Test
    void pathSuppliersHandleZeroLength() {
        for (List<Double> steps : List.of(
                new FixedStepsPathCompletionSupplier(10).compile(0),
                new EaseOutCubicPathCompletionSupplier(0.2).compile(0),
                new ConstantSpeedPathCompletionSupplier(0.2).compile(0))) {
            steps.forEach(step -> assertFalse(step.isNaN()));
            assertEquals(1.0, steps.get(steps.size() - 1));
        }
    }

    @Test
    void bezierWithoutTransformAndZeroLength() {
        ImmutableVector3i target = new ImmutableVector3i(3, 4, 5);
        BlockMoveQuadraticBezier bezier = new BlockMoveQuadraticBezier(new Vector3d(0, 0, 0), new EaseOutCubicPathCompletionSupplier(0.2), () -> 5D);
        CompiledBlockMoveAnimation moving = bezier.compile(target);
        assertEquals(BlockMoveType.PLACE, moving.frames().get(moving.frames().size() - 1).moveType());
        assertTrue(moving.frames().size() > 2);

        BlockMoveQuadraticBezier inPlace = new BlockMoveQuadraticBezier(target.asVector3d(), new EaseOutCubicPathCompletionSupplier(0.2), () -> 5D);
        for (BlockAnimationFrame frame : inPlace.compile(target).frames()) {
            assertTrue(frame.position().isFinite(), "no NaN positions");
        }
    }

    @Test
    void arrivalGrowEndsAsFullBlock() {
        ArrivalGrowTransformation grow = new ArrivalGrowTransformation(0.4F, 0.9, 1.5);
        org.joml.Vector3f scale = new org.joml.Vector3f();
        grow.getTransform(0.5).getScale(scale);
        assertEquals(0.4F, scale.x, 1.0E-4);
        grow.getTransform(0.95).getScale(scale);
        assertTrue(scale.x > 0.4F && scale.x < 1F, "grows near the target");
        Matrix4f end = grow.getTransform(1);
        assertTrue(end.equals(new Matrix4f(), 1.0E-5F), "full block, no rotation, no offset on arrival: " + end);
        // Уменьшенный блок остаётся по центру своей клетки
        org.joml.Vector3f center = grow.getTransform(0.2).transformPosition(new org.joml.Vector3f(0.5F, 0.5F, 0.5F));
        assertEquals(0.5F, center.x, 1.0E-4);
        assertEquals(0.5F, center.z, 1.0E-4);
    }

    @Test
    void bezierWithCustomControlPointArcsUp() {
        BlockMoveQuadraticBezier arc = BlockMoveQuadraticBezier.withControlPoint(ignored -> new Vector3d(0, 0, 0),
                new EaseOutCubicPathCompletionSupplier(0.3), (from, to) -> new Vector3d(from).lerp(to, 0.5).add(0, 8, 0));
        double maxY = arc.compile(new ImmutableVector3i(10, 0, 0)).frames().stream().mapToDouble(frame -> frame.position().y).max().orElse(0);
        assertTrue(maxY > 3, "path goes up, max y: " + maxY);
    }

    @Test
    @Timeout(10)
    void sequentialAnimationActuallyMovesBlocks() {
        TestSupplier supplier = new TestSupplier(cube(3));
        SequentialAnimation<String> animation = new SequentialAnimation<>(supplier, new ConstantSpeedPathCompletionSupplier(0.25), new LayeredBottomFirst(), 1000);
        animation.compile();
        Map<ImmutableVector3i, Integer> moveFrames = new HashMap<>();
        while (animation.getStatus() != Animation.AnimationStatus.COMPLETED) {
            for (Map.Entry<ImmutableVector3i, BlockAnimationFrame> entry : animation.getNext().currentToDestination().entrySet()) {
                if (entry.getValue().moveType() == BlockMoveType.MOVE) {
                    moveFrames.merge(entry.getKey(), 1, Integer::sum);
                }
            }
        }
        // Первый слой лететь неоткуда, а следующие должны вылетать из уже поставленных блоков
        long moving = moveFrames.values().stream().filter(frames -> frames > 1).count();
        assertTrue(moving >= 18, "blocks above the first layer have to move, moving: " + moving);
    }

    @Test
    @Timeout(10)
    void timerAnimationWithDuplicatePositionsCompletes() {
        List<ImmutableVector3i> positions = new ArrayList<>(cube(3));
        positions.addAll(cube(3));
        TestSupplier supplier = new TestSupplier(positions);
        TimerAnimation<String> animation = new TimerAnimation<>(new GrowingSelector(), new BlockMoveLinear(new Vector3d(10, 10, 10), new EaseOutCubicPathCompletionSupplier(0.5)), supplier, new LinearBlockTimer(10), 1000);
        animation.compile();
        RecordingAnimator blockAnimator = new RecordingAnimator(5);
        Animator<String> animator = new Animator<>(animation, blockAnimator);
        int ticks = 0;
        while (!animator.nextTick()) {
            ticks++;
            assertTrue(ticks < 10_000);
        }
        assertEquals(new HashSet<>(cube(3)), supplier.placed);
        assertTrue(blockAnimator.entities.isEmpty());
        assertEquals(1, blockAnimator.finishCalls);
    }

    @Test
    @Timeout(10)
    void emergencyFinishPlacesBufferedBlocksAndRemovesEntities() {
        TestSupplier supplier = new TestSupplier(cube(4));
        TimerAnimation<String> animation = new TimerAnimation<>(new BottomFirstSelector(), new BlockMoveLinear(new Vector3d(0, 20, 0), new EaseOutCubicPathCompletionSupplier(0.5)), supplier, new LinearBlockTimer(30), 1000);
        animation.compile();
        RecordingAnimator blockAnimator = new RecordingAnimator(1000);
        Animator<String> animator = new Animator<>(animation, blockAnimator);
        int[] completions = {0};
        animator.addOnCompletion(() -> completions[0]++);
        animator.addOnCompletion(() -> completions[0]++);
        // Первым блокам лететь 41 кадр, вся анимация ~70 тиков: на 55-м часть долетела, часть в пути
        for (int tick = 0; tick < 55; tick++) {
            animator.nextTick();
        }
        assertFalse(blockAnimator.waiting.isEmpty(), "test needs blocks that arrived but are not placed yet");
        animator.emergencyFinish();
        assertEquals(new HashSet<>(cube(4)), supplier.placed);
        assertTrue(blockAnimator.entities.isEmpty());
        assertEquals(2, completions[0], "both callbacks, once");
        assertTrue(animator.nextTick());
        animator.emergencyFinish();
        assertEquals(2, completions[0]);
        assertEquals(1, blockAnimator.finishCalls);
    }

    private static final class TestSupplier implements BlockSupplier<String> {
        private final List<ImmutableVector3i> positions;
        private final Set<ImmutableVector3i> placed = new HashSet<>();

        private TestSupplier(List<ImmutableVector3i> positions) {
            this.positions = positions;
        }

        @Override
        public String getBlock(ImmutableVector3i targetPosition) {
            return "stone";
        }

        @Override
        public List<ImmutableVector3i> getPositions() {
            return positions;
        }

        @Override
        public void placeBlock(ImmutableVector3i identifier) {
            placed.add(identifier);
        }
    }

    /** Ведёт себя как PlaceBlocksAfter: долетевшие блоки копятся и ставятся пачкой */
    private static final class RecordingAnimator implements BlockAnimator<String> {
        private final int batch;
        private final Set<ImmutableVector3i> entities = new HashSet<>();
        private final List<ImmutableVector3i> waiting = new ArrayList<>();
        private int finishCalls;

        private RecordingAnimator(int batch) {
            this.batch = batch;
        }

        @Override
        public void blockMove(ImmutableVector3i identifier, Vector3d to, BlockSupplier<String> blockSupplier, Matrix4f transform) {
            entities.add(identifier);
        }

        @Override
        public void blockPlace(ImmutableVector3i identifier, BlockSupplier<String> blockSupplier) {
            waiting.add(identifier);
            if (waiting.size() >= batch) {
                flush(blockSupplier);
            }
        }

        private void flush(BlockSupplier<String> blockSupplier) {
            blockSupplier.placeBlocks(waiting);
            waiting.forEach(entities::remove);
            waiting.clear();
        }

        @Override
        public void blockDestroy(ImmutableVector3i identifier) {
        }

        @Override
        public void finishAnimation(BlockSupplier<String> blockSupplier) {
            finishCalls++;
            flush(blockSupplier);
            entities.clear();
        }
    }
}
